import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Parsing tasks - задачи на парсинг
export const parsingTasks = pgTable("parsing_tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  url: text("url").notNull(),
  sourceType: text("source_type").notNull(), // "documentation", "website", "api_spec", "code_repository"
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  priority: text("priority").notNull().default("normal"), // low, normal, high, urgent
  options: jsonb("options"), // { depth: number, selectors: [], headers: {} }
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
});

// Parsing results - результаты парсинга
export const parsingResults = pgTable("parsing_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => parsingTasks.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  contentType: text("content_type").notNull(), // "html", "markdown", "json", "plain_text"
  metadata: jsonb("metadata"), // { title, description, author, date, links: [] }
  extractedData: jsonb("extracted_data"), // Structured data extracted from content
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Knowledge entries - накопленные знания
export const knowledgeEntries = pgTable("knowledge_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").references(() => parsingTasks.id, { onDelete: "set null" }),
  sourceType: text("source_type").notNull(),
  content: text("content").notNull(),
  summary: text("summary"), // AI-generated summary
  tags: text("tags").array(),
  category: text("category"), // "tutorial", "api_reference", "best_practice", "example"
  relevanceScore: text("relevance_score").default("0"), // 0-100
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Parsing logs - логи операций
export const parsingLogs = pgTable("parsing_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").references(() => parsingTasks.id, { onDelete: "cascade" }),
  level: text("level").notNull(), // "info", "warning", "error", "debug"
  message: text("message").notNull(),
  details: jsonb("details"),
  timestamp: timestamp("timestamp").notNull().default(sql`now()`),
});

// Integration credentials - учетные данные для интеграций
export const integrationCredentials = pgTable("integration_credentials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serviceName: text("service_name").notNull().unique(), // "aigentforge", "leadgen_pro", etc.
  apiKey: text("api_key"),
  webhookUrl: text("webhook_url"),
  config: jsonb("config"), // Additional service-specific config
  isActive: text("is_active").notNull().default("true"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Zod schemas
export const insertParsingTaskSchema = createInsertSchema(parsingTasks).omit({
  id: true,
  createdAt: true,
  startedAt: true,
  completedAt: true,
});

export const insertParsingResultSchema = createInsertSchema(parsingResults).omit({
  id: true,
  createdAt: true,
});

export const insertKnowledgeEntrySchema = createInsertSchema(knowledgeEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertParsingLogSchema = createInsertSchema(parsingLogs).omit({
  id: true,
  timestamp: true,
});

export const insertIntegrationCredentialSchema = createInsertSchema(integrationCredentials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type ParsingTask = typeof parsingTasks.$inferSelect;
export type InsertParsingTask = z.infer<typeof insertParsingTaskSchema>;

export type ParsingResult = typeof parsingResults.$inferSelect;
export type InsertParsingResult = z.infer<typeof insertParsingResultSchema>;

export type KnowledgeEntry = typeof knowledgeEntries.$inferSelect;
export type InsertKnowledgeEntry = z.infer<typeof insertKnowledgeEntrySchema>;

export type ParsingLog = typeof parsingLogs.$inferSelect;
export type InsertParsingLog = z.infer<typeof insertParsingLogSchema>;

export type IntegrationCredential = typeof integrationCredentials.$inferSelect;
export type InsertIntegrationCredential = z.infer<typeof insertIntegrationCredentialSchema>;

// HMM States - Hidden Markov Model состояния для AI-парсинга
export const hmmStates = pgTable("hmm_states", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => parsingTasks.id, { onDelete: "cascade" }),
  currentState: text("current_state").notNull(), // "initial" | "exploring" | "extracting" | "refining" | "completed" | "failed"
  previousState: text("previous_state"),
  transitionProbabilities: jsonb("transition_probabilities").notNull(),
  observations: jsonb("observations").notNull(),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Mouse Movements - Человекоподобные движения мыши
export const mouseMovements = pgTable("mouse_movements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => parsingTasks.id, { onDelete: "cascade" }),
  fromX: integer("from_x").notNull(),
  fromY: integer("from_y").notNull(),
  toX: integer("to_x").notNull(),
  toY: integer("to_y").notNull(),
  params: jsonb("params").notNull(), // MouseMovementParams
  bezierPoints: jsonb("bezier_points").notNull(),
  generatedBy: text("generated_by").notNull(), // "ai" | "default"
  aiPrompt: text("ai_prompt"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Browser Actions - Действия в браузере
export const browserActions = pgTable("browser_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => parsingTasks.id, { onDelete: "cascade" }),
  actionType: text("action_type").notNull(), // "navigate" | "click" | "type" | "scroll" | "wait" | "hover" | "screenshot" | "extract_html"
  context: jsonb("context").notNull(), // ActionContext: { selector?, text?, url?, scrollAmount?, waitTime?, mouseMovementId? }
  executeWithHMM: boolean("execute_with_hmm").notNull().default(true),
  status: text("status").notNull().default("pending"), // "pending" | "executing" | "completed" | "failed"
  result: jsonb("result"),
  error: text("error"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  executedAt: timestamp("executed_at"),
  completedAt: timestamp("completed_at"),
});

// AI Decisions Log - Логирование решений AI
export const aiDecisionsLog = pgTable("ai_decisions_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => parsingTasks.id, { onDelete: "cascade" }),
  decisionType: text("decision_type").notNull(), // "mouse_movement" | "selector_generation" | "strategy_adaptation" | "next_action"
  inputData: jsonb("input_data").notNull(),
  mistralResponse: jsonb("mistral_response"),
  actionTaken: text("action_taken").notNull(),
  result: text("result"),
  timestamp: timestamp("timestamp").notNull().default(sql`now()`),
});

// Zod schemas for new tables
export const insertHMMStateSchema = createInsertSchema(hmmStates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMouseMovementSchema = createInsertSchema(mouseMovements).omit({
  id: true,
  createdAt: true,
});

export const insertBrowserActionSchema = createInsertSchema(browserActions).omit({
  id: true,
  createdAt: true,
  executedAt: true,
  completedAt: true,
});

export const insertAIDecisionLogSchema = createInsertSchema(aiDecisionsLog).omit({
  id: true,
  timestamp: true,
});

// Types for new tables
export type HMMState = typeof hmmStates.$inferSelect;
export type InsertHMMState = z.infer<typeof insertHMMStateSchema>;

export type MouseMovement = typeof mouseMovements.$inferSelect;
export type InsertMouseMovement = z.infer<typeof insertMouseMovementSchema>;

export type BrowserAction = typeof browserActions.$inferSelect;
export type InsertBrowserAction = z.infer<typeof insertBrowserActionSchema>;

export type AIDecisionLog = typeof aiDecisionsLog.$inferSelect;
export type InsertAIDecisionLog = z.infer<typeof insertAIDecisionLogSchema>;
