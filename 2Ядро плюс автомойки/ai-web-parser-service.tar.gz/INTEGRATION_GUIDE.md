# Parser Service - Руководство по Интеграции

## Быстрый Старт (5 минут)

### Шаг 1: Добавить Роуты в Основное Приложение

```typescript
// server/routes.ts
import { parserRouter } from "../parser-service/infrastructure/routes";

// Добавить перед другими роутами
app.use("/api/parser", parserRouter);
```

### Шаг 2: Пуш Database Schema

```bash
npm run db:push
```

Это создаст 5 новых таблиц:
- `parsing_tasks`
- `parsing_results`
- `knowledge_entries`
- `parsing_logs`
- `integration_credentials`

### Шаг 3: Готово!

Parser Service теперь доступен по адресу:
```
http://localhost:5000/api/parser/
```

---

## Интеграция с AiGentForge

### Сценарий: Парсинг документации для улучшения генерации агентов

```typescript
// server/services/aigent-parser-service.ts
import axios from "axios";

export class AiGentParserService {
  private parserBaseUrl = "http://localhost:5000/api/parser";

  /**
   * Парсит документацию и добавляет в базу знаний
   */
  async enrichKnowledgeBase(documentationUrl: string): Promise<{
    taskId: string;
    knowledgeEntries: number;
  }> {
    // 1. Create parsing task
    const createResponse = await axios.post(`${this.parserBaseUrl}/tasks`, {
      url: documentationUrl,
      sourceType: "documentation",
      priority: "high",
      options: {
        depth: 3,
        maxPages: 50,
        followLinks: true,
        extractStructuredData: true,
        selectors: [".main-content", "article", ".documentation"],
      },
    });

    const taskId = createResponse.data.taskId;

    // 2. Execute parsing
    await axios.post(`${this.parserBaseUrl}/tasks/${taskId}/parse`);

    // 3. Poll for completion
    let attempts = 0;
    const maxAttempts = 30;

    while (attempts < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const statusResponse = await axios.get(`${this.parserBaseUrl}/tasks/${taskId}`);
      const status = statusResponse.data.status;

      if (status === "completed") {
        // Success!
        return {
          taskId,
          knowledgeEntries: statusResponse.data.knowledgeEntries || 0,
        };
      }

      if (status === "failed") {
        throw new Error("Documentation parsing failed");
      }

      attempts++;
    }

    throw new Error("Parsing timeout");
  }

  /**
   * Парсит примеры кода из GitHub репозитория
   */
  async parseCodeExamples(repoUrl: string): Promise<string[]> {
    const createResponse = await axios.post(`${this.parserBaseUrl}/tasks`, {
      url: repoUrl,
      sourceType: "code_repository",
      priority: "normal",
      options: {
        depth: 2,
        selectors: ["pre code", ".highlight"],
      },
    });

    const taskId = createResponse.data.taskId;
    await axios.post(`${this.parserBaseUrl}/tasks/${taskId}/parse`);

    // Wait and get results...
    return [];
  }
}

// Использование в агенте
export async function enhanceAgentKnowledge(agentId: string) {
  const parserService = new AiGentParserService();

  // Parse TypeScript docs
  await parserService.enrichKnowledgeBase("https://www.typescriptlang.org/docs/");

  // Parse Express docs
  await parserService.enrichKnowledgeBase("https://expressjs.com/en/api.html");

  // Parse Drizzle docs
  await parserService.enrichKnowledgeBase("https://orm.drizzle.team/docs/overview");

  console.log("Agent knowledge base enriched!");
}
```

### API endpoint для автоматического обогащения

```typescript
// server/routes.ts
app.post("/api/agents/:id/enrich-knowledge", async (req, res) => {
  const { id } = req.params;
  const { documentationUrls } = req.body;

  const parserService = new AiGentParserService();
  const results = [];

  for (const url of documentationUrls) {
    const result = await parserService.enrichKnowledgeBase(url);
    results.push(result);
  }

  res.json({
    agentId: id,
    enriched: results.length,
    totalKnowledgeEntries: results.reduce((sum, r) => sum + r.knowledgeEntries, 0),
  });
});
```

---

## Интеграция с LeadGen Pro

### Сценарий 1: Парсинг бизнес-каталогов

```typescript
// server/services/leadgen-parser-service.ts
import axios from "axios";

export class LeadGenParserService {
  private parserBaseUrl = "http://localhost:5000/api/parser";

  /**
   * Парсит каталог бизнесов (2GIS, Яндекс.Карты, Yellow Pages)
   */
  async parseBusinessCatalog(params: {
    url: string;
    vertical: "coffee" | "beauty" | "tutor";
    city: string;
  }): Promise<any[]> {
    // 1. Create parsing task
    const createResponse = await axios.post(`${this.parserBaseUrl}/tasks`, {
      url: params.url,
      sourceType: "website",
      priority: "urgent",
      options: {
        depth: 2,
        maxPages: 100,
        selectors: [
          ".business-card",
          ".listing",
          '[itemtype="http://schema.org/LocalBusiness"]',
        ],
        extractStructuredData: true, // Извлечь microdata, JSON-LD
      },
    });

    const taskId = createResponse.data.taskId;

    // 2. Execute parsing
    const parseResponse = await axios.post(`${this.parserBaseUrl}/tasks/${taskId}/parse`);

    // 3. Transform results to BusinessProfile format
    const businesses = this.transformToBusinessProfiles(
      parseResponse.data,
      params.vertical,
      params.city
    );

    return businesses;
  }

  /**
   * Парсит конкурентов в городе
   */
  async analyzeCompetitors(params: {
    vertical: string;
    city: string;
    radius: number;
  }): Promise<{
    totalCompetitors: number;
    averageRating: number;
    priceRange: { min: number; max: number };
  }> {
    // Implementation using parser
    return {
      totalCompetitors: 0,
      averageRating: 0,
      priceRange: { min: 0, max: 0 },
    };
  }

  private transformToBusinessProfiles(data: any, vertical: string, city: string): any[] {
    // Transform parsed data to BusinessProfile entities
    return [];
  }
}

// Использование в LeadGen
export async function importLeadsFromCatalog(vertical: string, city: string) {
  const parserService = new LeadGenParserService();

  // Parse 2GIS
  const businesses = await parserService.parseBusinessCatalog({
    url: `https://2gis.ru/search/${vertical}?city=${city}`,
    vertical: vertical as any,
    city,
  });

  // Import to LeadGen
  for (const business of businesses) {
    await axios.post("http://localhost:5000/api/leadgen/profiles/import", {
      profiles: [business],
    });
  }

  console.log(`Imported ${businesses.length} businesses from 2GIS`);
}
```

### Сценарий 2: Мониторинг новых бизнесов

```typescript
// server/services/leadgen-monitor-service.ts
export class LeadGenMonitorService {
  /**
   * Ежедневный парсинг новых бизнесов
   */
  async dailyBusinessScan(cities: string[], vertical: string): Promise<void> {
    const parserService = new LeadGenParserService();

    for (const city of cities) {
      // Parse каждый день
      const businesses = await parserService.parseBusinessCatalog({
        url: `https://2gis.ru/search/${vertical}?city=${city}`,
        vertical: vertical as any,
        city,
      });

      // Check for new businesses
      for (const business of businesses) {
        const exists = await this.checkBusinessExists(business.phone);

        if (!exists) {
          // New business found!
          await this.createLead(business);
          await this.sendNotification(`New ${vertical} business found in ${city}!`);
        }
      }
    }
  }

  private async checkBusinessExists(phone: string): Promise<boolean> {
    // Check in database
    return false;
  }

  private async createLead(business: any): Promise<void> {
    // Create lead in LeadGen
  }

  private async sendNotification(message: string): Promise<void> {
    // Send notification
  }
}

// Cron job (запускать каждый день в 9:00)
import cron from "node-cron";

cron.schedule("0 9 * * *", async () => {
  const monitor = new LeadGenMonitorService();
  await monitor.dailyBusinessScan(["Москва", "Санкт-Петербург"], "coffee");
});
```

---

## Интеграция с Любой Системой

### Пример 1: Простой Node.js скрипт

```typescript
// scripts/parse-and-save.ts
import axios from "axios";
import fs from "fs";

async function parseAndSave(url: string, outputFile: string) {
  // 1. Create task
  const { data: createData } = await axios.post("http://localhost:5000/api/parser/tasks", {
    url,
    sourceType: "documentation",
  });

  const taskId = createData.taskId;

  // 2. Parse
  await axios.post(`http://localhost:5000/api/parser/tasks/${taskId}/parse`);

  // 3. Wait for completion
  let status = "processing";
  while (status !== "completed" && status !== "failed") {
    await new Promise((resolve) => setTimeout(resolve, 2000));
    const { data: statusData } = await axios.get(
      `http://localhost:5000/api/parser/tasks/${taskId}`
    );
    status = statusData.status;
  }

  if (status === "failed") {
    throw new Error("Parsing failed");
  }

  // 4. Get results
  const { data: results } = await axios.get(
    `http://localhost:5000/api/parser/results/${taskId}`
  );

  // 5. Save to file
  fs.writeFileSync(outputFile, JSON.stringify(results, null, 2));
  console.log(`Saved to ${outputFile}`);
}

// Usage
parseAndSave("https://docs.python.org/3/", "./python-docs.json");
```

### Пример 2: Webhook интеграция

```typescript
// server/webhooks/parser-webhook.ts
import express from "express";
import axios from "axios";

const app = express();

app.post("/webhook/parse-complete", async (req, res) => {
  const { taskId, status, knowledgeEntries } = req.body;

  if (status === "completed") {
    console.log(`Task ${taskId} completed with ${knowledgeEntries} knowledge entries`);

    // Do something with the results
    await notifySlack(`Parsing completed! ${knowledgeEntries} new entries.`);
  }

  res.json({ received: true });
});

async function notifySlack(message: string) {
  // Send to Slack
}
```

### Пример 3: Queue-based интеграция (для высоконагруженных систем)

```typescript
// services/parser-queue-service.ts
import Bull from "bull";
import axios from "axios";

const parserQueue = new Bull("parser-queue", {
  redis: { host: "localhost", port: 6379 },
});

// Producer: Add parsing jobs to queue
export async function queueParsingTask(url: string, sourceType: string) {
  await parserQueue.add("parse", {
    url,
    sourceType,
    priority: "normal",
  });
}

// Consumer: Process parsing jobs
parserQueue.process("parse", async (job) => {
  const { url, sourceType } = job.data;

  // Create task
  const { data } = await axios.post("http://localhost:5000/api/parser/tasks", {
    url,
    sourceType,
  });

  // Parse
  await axios.post(`http://localhost:5000/api/parser/tasks/${data.taskId}/parse`);

  // Wait for completion
  // ...

  return { taskId: data.taskId, status: "completed" };
});

// Usage
await queueParsingTask("https://example.com", "documentation");
await queueParsingTask("https://another-site.com", "website");
// Queue will process them one by one
```

---

## Best Practices

### 1. Обработка Ошибок

```typescript
try {
  const result = await parserService.enrichKnowledgeBase(url);
} catch (error) {
  if (error.response?.status === 404) {
    console.error("Task not found");
  } else if (error.response?.status === 500) {
    console.error("Parser service error");
  } else {
    console.error("Unknown error:", error);
  }
}
```

### 2. Retry Mechanism

```typescript
async function parseWithRetry(url: string, maxRetries: number = 3): Promise<any> {
  let attempts = 0;

  while (attempts < maxRetries) {
    try {
      return await parserService.enrichKnowledgeBase(url);
    } catch (error) {
      attempts++;
      if (attempts >= maxRetries) throw error;
      await new Promise((resolve) => setTimeout(resolve, 5000 * attempts));
    }
  }
}
```

### 3. Batch Processing

```typescript
async function parseBatch(urls: string[]): Promise<void> {
  const BATCH_SIZE = 5;

  for (let i = 0; i < urls.length; i += BATCH_SIZE) {
    const batch = urls.slice(i, i + BATCH_SIZE);
    await Promise.all(batch.map((url) => parserService.enrichKnowledgeBase(url)));

    // Pause between batches
    if (i + BATCH_SIZE < urls.length) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  }
}
```

### 4. Monitoring

```typescript
// Track parser metrics
let totalParsed = 0;
let totalFailed = 0;

async function parseWithMetrics(url: string) {
  try {
    await parserService.enrichKnowledgeBase(url);
    totalParsed++;
  } catch (error) {
    totalFailed++;
    throw error;
  }
}

// Log metrics every hour
setInterval(() => {
  console.log(`Parser metrics: ${totalParsed} parsed, ${totalFailed} failed`);
}, 3600000);
```

---

## Примеры Полной Интеграции

### AiGentForge + Parser Service

```typescript
// Когда пользователь создает агента, автоматически обогащаем базу знаний
app.post("/api/agents", async (req, res) => {
  const { name, description, task } = req.body;

  // 1. Create agent (existing logic)
  const agent = await createAgent({ name, description, task });

  // 2. Enrich knowledge base based on task
  const parserService = new AiGentParserService();

  if (task.includes("TypeScript")) {
    await parserService.enrichKnowledgeBase("https://www.typescriptlang.org/docs/");
  }

  if (task.includes("Express")) {
    await parserService.enrichKnowledgeBase("https://expressjs.com/en/api.html");
  }

  res.json(agent);
});
```

### LeadGen Pro + Parser Service

```typescript
// Автоматический импорт лидов из каталогов
app.post("/api/leadgen/auto-import", async (req, res) => {
  const { vertical, cities } = req.body;

  const parserService = new LeadGenParserService();
  let totalImported = 0;

  for (const city of cities) {
    const businesses = await parserService.parseBusinessCatalog({
      url: `https://2gis.ru/search/${vertical}?city=${city}`,
      vertical,
      city,
    });

    // Import each business
    for (const business of businesses) {
      await axios.post("http://localhost:5000/api/leadgen/profiles/import", {
        profiles: [business],
      });
      totalImported++;
    }
  }

  res.json({ imported: totalImported, cities: cities.length });
});
```

---

## Troubleshooting

### Problem: Parsing timeout

**Solution:** Increase maxAttempts or intervalMs

```typescript
const statusResponse = await axios.get(
  `${this.parserBaseUrl}/tasks/${taskId}`,
  { timeout: 60000 } // 60 seconds
);
```

### Problem: External parser unavailable

**Solution:** Parser Service автоматически fallback на встроенный парсер

```typescript
// Check health first
const health = await axios.get(`${parserBaseUrl}/health`);
if (health.data.parserGateway.status === "unhealthy") {
  console.warn("External parser unavailable, using built-in parser");
}
```

### Problem: Too many tasks

**Solution:** Use queue system (Bull, RabbitMQ)

```typescript
// Instead of direct API calls
await parserQueue.add({ url, sourceType });
```

---

## Roadmap Integration Features

- [ ] GraphQL API для более гибких запросов
- [ ] WebSocket для real-time прогресса парсинга
- [ ] Webhook callbacks при завершении задачи
- [ ] SDK библиотеки (TypeScript, Python, Go)
- [ ] CLI tool для командной строки

---

## Поддержка

**Документация:**
- Техническая: `parser-service/README.md`
- Интеграция: `parser-service/INTEGRATION_GUIDE.md` (этот файл)

**Версия:** 1.0.0  
**Дата:** 08.10.2025
