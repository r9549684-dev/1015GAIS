import type { IBrowserActionRepository } from "../ports/IBrowserActionRepository";
import type { BrowserAction } from "../../shared/schema";

export class GetBrowserActionsUseCase {
  constructor(private actionRepo: IBrowserActionRepository) {}

  async execute(taskId: string, limit?: number): Promise<BrowserAction[]> {
    return await this.actionRepo.getByTaskId(taskId, limit);
  }
}
