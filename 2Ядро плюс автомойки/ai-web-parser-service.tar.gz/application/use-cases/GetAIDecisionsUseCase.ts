import type { IAIDecisionLogRepository } from "../ports/IAIDecisionLogRepository";
import type { AIDecisionLog } from "../../shared/schema";

export class GetAIDecisionsUseCase {
  constructor(private aiLogRepo: IAIDecisionLogRepository) {}

  async execute(taskId: string, limit?: number): Promise<AIDecisionLog[]> {
    return await this.aiLogRepo.getByTaskId(taskId, limit);
  }
}
