import type { IParsingTaskRepository } from "../../adapters/repositories/IParsingTaskRepository";
import type { IParsingResultRepository } from "../../adapters/repositories/IParsingResultRepository";
import type { IMistralGateway } from "../../adapters/gateways/IMistralGateway";
import type { IPlaywrightGateway } from "../../adapters/gateways/IPlaywrightGateway";
import type { IHMMGateway } from "../../adapters/gateways/IHMMGateway";

export interface ExecuteAIParsingRequest {
  taskId: string;
  url: string;
  sourceType: string;
  enableHMM: boolean;
  maxPages?: number;
}

export interface ExecuteAIParsingResponse {
  taskId: string;
  resultId: string;
  pagesProcessed: number;
  dataExtracted: number;
  hmmSuccessRate: number;
  finalState: string;
}

export class ExecuteAIParsingUseCase {
  constructor(
    private taskRepository: IParsingTaskRepository,
    private resultRepository: IParsingResultRepository,
    private mistralGateway: IMistralGateway,
    private playwrightGateway: IPlaywrightGateway,
    private hmmGateway: IHMMGateway
  ) {}

  async execute(request: ExecuteAIParsingRequest): Promise<ExecuteAIParsingResponse> {
    // 1. Инициализация HMM состояния (initial)
    const hmmState = await this.hmmGateway.initializeState(request.taskId);

    // 2. Обновление статуса задачи
    await this.taskRepository.updateStatus(request.taskId, "processing");

    try {
      // 3. Инициализация браузера
      await this.playwrightGateway.initialize({
        headless: true,
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0",
      });

      // 4. Переход к состоянию exploring
      await this.hmmGateway.transition(request.taskId, "exploring");

      // 5. Навигация на целевую страницу
      const page = await this.playwrightGateway.navigate(request.url);

      // 6. Анализ HTML структуры через Mistral
      const analysis = await this.mistralGateway.analyzeHTMLStructure(
        page.html.substring(0, 5000), // Первые 5KB для анализа
        request.sourceType
      );

      // 7. Добавление наблюдения: успешная навигация
      await this.hmmGateway.addObservation(request.taskId, {
        action: "navigate",
        success: true,
        metrics: { pagesProcessed: 1 },
      });

      // 8. Переход к состоянию extracting
      await this.hmmGateway.transition(request.taskId, "extracting");

      // 9. Извлечение данных с использованием AI-селекторов
      const extractedData = await this.extractDataWithSelectors(
        request.taskId,
        analysis.selectors,
        request.enableHMM
      );

      // 10. Оценка качества извлечения
      const qualityScore = this.evaluateQuality(extractedData, request.sourceType);

      // 11. Если качество низкое - переход к refining
      if (qualityScore < 0.7 && analysis.confidence < 0.8) {
        await this.hmmGateway.transition(request.taskId, "refining");

        // Запрос улучшенных селекторов у Mistral
        const refinedStrategy = await this.mistralGateway.generateExtractionStrategy({
          url: request.url,
          sourceType: request.sourceType,
          htmlStructure: page.html.substring(0, 10000),
        });

        // Повторное извлечение
        // ... (реализация повторного извлечения)
      }

      // 12. Сохранение результатов
      const result = await this.resultRepository.create({
        taskId: request.taskId,
        content: JSON.stringify(extractedData),
        contentType: "json",
        metadata: { sourceUrl: request.url },
        extractedData: extractedData,
      });

      // 13. Переход к состоянию completed
      await this.hmmGateway.transition(request.taskId, "completed");
      await this.taskRepository.updateStatus(request.taskId, "completed");

      // 14. Оценка стратегии HMM
      const strategyEval = await this.hmmGateway.evaluateStrategy(request.taskId);

      // 15. Закрытие браузера
      await this.playwrightGateway.close();

      return {
        taskId: request.taskId,
        resultId: result.id,
        pagesProcessed: 1,
        dataExtracted: extractedData.length,
        hmmSuccessRate: strategyEval.successRate,
        finalState: "completed",
      };
    } catch (error: any) {
      // Обработка ошибок
      await this.hmmGateway.transition(request.taskId, "failed");
      await this.taskRepository.updateStatus(request.taskId, "failed", error.message);

      await this.hmmGateway.addObservation(request.taskId, {
        action: "parsing",
        success: false,
      });

      await this.playwrightGateway.close();

      throw error;
    }
  }

  private async extractDataWithSelectors(
    taskId: string,
    selectors: string[],
    enableHMM: boolean
  ): Promise<any[]> {
    // Реализация извлечения данных
    // Использует Playwright для извлечения элементов по селекторам
    return [];
  }

  private evaluateQuality(data: any[], sourceType: string): number {
    if (data.length === 0) return 0;
    // Простая оценка: если извлечены данные - качество высокое
    return Math.min(data.length / 10, 1.0);
  }
}
