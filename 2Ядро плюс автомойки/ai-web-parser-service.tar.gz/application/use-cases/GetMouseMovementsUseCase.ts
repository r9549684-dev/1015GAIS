import type { IMouseMovementRepository } from "../ports/IMouseMovementRepository";
import type { MouseMovement } from "../../shared/schema";

export class GetMouseMovementsUseCase {
  constructor(private mouseRepo: IMouseMovementRepository) {}

  async execute(taskId: string, limit?: number): Promise<MouseMovement[]> {
    return await this.mouseRepo.getByTaskId(taskId, limit);
  }
}
