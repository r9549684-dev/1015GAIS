import type { IHMMStateRepository } from "../ports/IHMMStateRepository";
import type { HMMState } from "../../shared/schema";

export class GetHMMStateUseCase {
  constructor(private hmmRepo: IHMMStateRepository) {}

  async execute(taskId: string): Promise<HMMState | null> {
    return await this.hmmRepo.getByTaskId(taskId);
  }
}
