import type { IParsingTaskRepository } from "../../adapters/repositories/IParsingTaskRepository";
import type { ParsingTask } from "../../shared/schema";

export interface GetTaskStatusResponse {
  taskId: string;
  status: string;
  url: string;
  sourceType: string;
  createdAt: Date;
  startedAt: Date | null;
  completedAt: Date | null;
  duration: number | null;
}

export class GetTaskStatusUseCase {
  constructor(private readonly taskRepository: IParsingTaskRepository) {}

  async execute(taskId: string): Promise<GetTaskStatusResponse> {
    const task = await this.taskRepository.getById(taskId);

    if (!task) {
      throw new Error(`Task not found: ${taskId}`);
    }

    const duration = this.calculateDuration(task);

    return {
      taskId: task.id,
      status: task.status,
      url: task.url,
      sourceType: task.sourceType,
      createdAt: task.createdAt,
      startedAt: task.startedAt,
      completedAt: task.completedAt,
      duration,
    };
  }

  private calculateDuration(task: ParsingTask): number | null {
    if (!task.startedAt || !task.completedAt) {
      return null;
    }
    return new Date(task.completedAt).getTime() - new Date(task.startedAt).getTime();
  }
}
