import { ParsingResultEntity } from "../../domain/entities/ParsingResult";
import { KnowledgeEntryEntity } from "../../domain/entities/KnowledgeEntry";
import type { IParsingTaskRepository } from "../../adapters/repositories/IParsingTaskRepository";
import type { IParsingResultRepository } from "../../adapters/repositories/IParsingResultRepository";
import type { IKnowledgeEntryRepository } from "../../adapters/repositories/IKnowledgeEntryRepository";
import type { IParserGateway } from "../../adapters/gateways/IParserGateway";
import type { IParsingLogger } from "../../adapters/gateways/IParsingLogger";

export interface ParseDocumentationResponse {
  taskId: string;
  resultId: string;
  knowledgeEntries: number;
  status: string;
}

export class ParseDocumentationUseCase {
  constructor(
    private readonly taskRepository: IParsingTaskRepository,
    private readonly resultRepository: IParsingResultRepository,
    private readonly knowledgeRepository: IKnowledgeEntryRepository,
    private readonly parserGateway: IParserGateway,
    private readonly logger: IParsingLogger
  ) {}

  async execute(taskId: string): Promise<ParseDocumentationResponse> {
    // 1. Get task
    const task = await this.taskRepository.getById(taskId);
    if (!task) {
      throw new Error(`Task not found: ${taskId}`);
    }

    if (task.status !== "pending") {
      throw new Error(`Task is not in pending status: ${task.status}`);
    }

    try {
      // 2. Start task
      await this.taskRepository.updateStatus(taskId, "processing", new Date());
      await this.logger.info(`Starting parsing task: ${taskId}`, { url: task.url });

      // 3. Parse content using gateway
      const parsedContent = await this.parserGateway.parseUrl(task.url, task.options);

      // 4. Create parsing result
      const resultData = ParsingResultEntity.create(
        taskId,
        parsedContent.content,
        parsedContent.contentType,
        parsedContent.metadata,
        parsedContent.extractedData
      );

      const result = await this.resultRepository.create(resultData);

      // 5. Extract knowledge entries
      const knowledgeEntries = this.extractKnowledge(
        taskId,
        parsedContent.content,
        parsedContent.metadata,
        parsedContent.extractedData
      );

      // 6. Save knowledge entries
      let savedCount = 0;
      for (const entry of knowledgeEntries) {
        await this.knowledgeRepository.create(entry);
        savedCount++;
      }

      // 7. Complete task
      await this.taskRepository.updateStatus(taskId, "completed", undefined, new Date());
      await this.logger.info(`Parsing task completed: ${taskId}`, {
        resultId: result.id,
        knowledgeEntries: savedCount,
      });

      return {
        taskId,
        resultId: result.id,
        knowledgeEntries: savedCount,
        status: "completed",
      };
    } catch (error: any) {
      // Handle failure
      await this.taskRepository.updateStatus(taskId, "failed", undefined, new Date());
      await this.logger.error(`Parsing task failed: ${taskId}`, {
        error: error.message,
        url: task.url,
      });
      throw error;
    }
  }

  private extractKnowledge(
    taskId: string,
    content: string,
    metadata: any,
    extractedData: any
  ): Omit<KnowledgeEntryEntity, "id" | "createdAt" | "updatedAt" | "summary" | "relevanceScore">[] {
    const entries: any[] = [];

    // Extract from code blocks
    if (extractedData.codeBlocks && Array.isArray(extractedData.codeBlocks)) {
      for (const codeBlock of extractedData.codeBlocks) {
        entries.push(
          KnowledgeEntryEntity.create(
            "code_example",
            codeBlock.code,
            "example",
            ["code", codeBlock.language],
            taskId,
            { language: codeBlock.language }
          )
        );
      }
    }

    // Extract from headings (as API reference or tutorial sections)
    if (extractedData.headings && Array.isArray(extractedData.headings)) {
      const mainHeadings = extractedData.headings.filter((h: any) => h.level <= 2);
      for (const heading of mainHeadings) {
        entries.push(
          KnowledgeEntryEntity.create(
            "documentation",
            heading.text,
            "api_reference",
            ["heading", "documentation"],
            taskId,
            { level: heading.level }
          )
        );
      }
    }

    // Extract main content as general knowledge
    if (content && content.length > 100) {
      const excerpt = content.substring(0, 1000);
      entries.push(
        KnowledgeEntryEntity.create(
          "documentation",
          excerpt,
          "general",
          ["documentation", metadata.language || "unknown"],
          taskId,
          {
            title: metadata.title,
            url: metadata.links?.[0],
          }
        )
      );
    }

    return entries;
  }
}
