import { ParsingTaskEntity, SourceType, ParsingPriority, ParsingOptions } from "../../domain/entities/ParsingTask";
import type { IParsingTaskRepository } from "../../adapters/repositories/IParsingTaskRepository";
import type { IParsingLogger } from "../../adapters/gateways/IParsingLogger";

export interface CreateParsingTaskRequest {
  url: string;
  sourceType: SourceType;
  priority?: ParsingPriority;
  options?: ParsingOptions;
}

export interface CreateParsingTaskResponse {
  taskId: string;
  status: string;
  message: string;
}

export class CreateParsingTaskUseCase {
  constructor(
    private readonly taskRepository: IParsingTaskRepository,
    private readonly logger: IParsingLogger
  ) {}

  async execute(request: CreateParsingTaskRequest): Promise<CreateParsingTaskResponse> {
    // Create entity
    const taskData = ParsingTaskEntity.create(
      request.url,
      request.sourceType,
      request.priority || "normal",
      request.options || {}
    );

    // Validate
    const tempEntity = new ParsingTaskEntity(
      "temp",
      taskData.url,
      taskData.sourceType,
      taskData.status,
      taskData.priority,
      taskData.options,
      new Date(),
      null,
      null
    );

    const validation = tempEntity.validate();
    if (!validation.valid) {
      await this.logger.error(`Task validation failed: ${validation.errors.join(", ")}`, {
        url: request.url,
        errors: validation.errors,
      });
      throw new Error(`Validation failed: ${validation.errors.join(", ")}`);
    }

    // Save to repository
    const savedTask = await this.taskRepository.create(taskData);

    await this.logger.info(`Parsing task created: ${savedTask.id}`, {
      taskId: savedTask.id,
      url: savedTask.url,
      sourceType: savedTask.sourceType,
    });

    return {
      taskId: savedTask.id,
      status: savedTask.status,
      message: `Parsing task created successfully`,
    };
  }
}
