import type { IMistralGateway } from "../../adapters/gateways/IMistralGateway";
import { MouseMovementEntity } from "../../domain/entities/MouseMovement";

export interface GenerateHumanMouseRequest {
  taskId: string;
  actionType: "click" | "hover";
  targetElement: string;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
}

export interface GenerateHumanMouseResponse {
  movement: MouseMovementEntity;
  estimatedDuration: number;
  isHumanLike: boolean;
}

export class GenerateHumanMouseMovementUseCase {
  constructor(private mistralGateway: IMistralGateway) {}

  async execute(request: GenerateHumanMouseRequest): Promise<GenerateHumanMouseResponse> {
    const distance = this.calculateDistance(
      request.fromX,
      request.fromY,
      request.toX,
      request.toY
    );

    try {
      // 1. Генерация параметров через Mistral AI
      const aiParams = await this.mistralGateway.generateMouseMovementParams({
        actionType: request.actionType,
        targetElement: request.targetElement,
        distance,
      });

      // 2. Создание entity с AI параметрами
      const movement = new MouseMovementEntity(
        "", // ID будет сгенерирован при сохранении
        request.taskId,
        request.fromX,
        request.fromY,
        request.toX,
        request.toY,
        aiParams,
        this.generateBezierPoints(request.fromX, request.fromY, request.toX, request.toY, aiParams.curvature),
        "ai",
        `Generate ${request.actionType} movement for ${request.targetElement}`,
        new Date()
      );

      return {
        movement,
        estimatedDuration: movement.getEstimatedDuration(),
        isHumanLike: movement.isHumanLike(),
      };
    } catch (error) {
      // Fallback: использовать default параметры если AI недоступен
      console.warn("AI unavailable, using default mouse movement params:", error);

      const defaultParams = MouseMovementEntity.getDefaultParams();
      
      const movement = new MouseMovementEntity(
        "",
        request.taskId,
        request.fromX,
        request.fromY,
        request.toX,
        request.toY,
        defaultParams,
        this.generateBezierPoints(request.fromX, request.fromY, request.toX, request.toY, defaultParams.curvature),
        "default",
        null,
        new Date()
      );

      return {
        movement,
        estimatedDuration: movement.getEstimatedDuration(),
        isHumanLike: movement.isHumanLike(),
      };
    }
  }

  private calculateDistance(x1: number, y1: number, x2: number, y2: number): number {
    const dx = x2 - x1;
    const dy = y2 - y1;
    return Math.sqrt(dx * dx + dy * dy);
  }

  private generateBezierPoints(
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    curvature: number
  ): Array<{ x: number; y: number }> {
    // Генерация контрольных точек для кривой Безье
    const controlPoint1X = x1 + (x2 - x1) * 0.25 + (Math.random() - 0.5) * curvature * 100;
    const controlPoint1Y = y1 + (y2 - y1) * 0.25 + (Math.random() - 0.5) * curvature * 100;
    const controlPoint2X = x1 + (x2 - x1) * 0.75 + (Math.random() - 0.5) * curvature * 100;
    const controlPoint2Y = y1 + (y2 - y1) * 0.75 + (Math.random() - 0.5) * curvature * 100;

    // Кубическая кривая Безье: P(t) = (1-t)³P0 + 3(1-t)²tP1 + 3(1-t)t²P2 + t³P3
    const points: Array<{ x: number; y: number }> = [];
    const steps = 50;

    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const mt = 1 - t;
      const mt2 = mt * mt;
      const mt3 = mt2 * mt;
      const t2 = t * t;
      const t3 = t2 * t;

      const x = mt3 * x1 + 3 * mt2 * t * controlPoint1X + 3 * mt * t2 * controlPoint2X + t3 * x2;
      const y = mt3 * y1 + 3 * mt2 * t * controlPoint1Y + 3 * mt * t2 * controlPoint2Y + t3 * y2;

      points.push({ x, y });
    }

    return points;
  }
}
