import type { MouseMovement, InsertMouseMovement } from "../../shared/schema";

export interface IMouseMovementRepository {
  create(data: InsertMouseMovement): Promise<MouseMovement>;
  getByTaskId(taskId: string, limit?: number): Promise<MouseMovement[]>;
  getById(id: string): Promise<MouseMovement | null>;
}
