import type { AIDecisionLog, InsertAIDecisionLog } from "../../shared/schema";

export interface IAIDecisionLogRepository {
  create(data: InsertAIDecisionLog): Promise<AIDecisionLog>;
  getByTaskId(taskId: string, limit?: number): Promise<AIDecisionLog[]>;
  getById(id: string): Promise<AIDecisionLog | null>;
  getByDecisionType(taskId: string, decisionType: string): Promise<AIDecisionLog[]>;
}
