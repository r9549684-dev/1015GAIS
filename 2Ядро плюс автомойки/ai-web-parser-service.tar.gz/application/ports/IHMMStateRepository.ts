import type { HMMState, InsertHMMState } from "../../shared/schema";

export interface IHMMStateRepository {
  create(data: InsertHMMState): Promise<HMMState>;
  getByTaskId(taskId: string): Promise<HMMState | null>;
  update(id: string, data: Partial<InsertHMMState>): Promise<HMMState | null>;
  delete(id: string): Promise<void>;
}
