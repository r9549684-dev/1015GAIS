import type { BrowserAction, InsertBrowserAction } from "../../shared/schema";

export interface IBrowserActionRepository {
  create(data: InsertBrowserAction): Promise<BrowserAction>;
  getByTaskId(taskId: string, limit?: number): Promise<BrowserAction[]>;
  getById(id: string): Promise<BrowserAction | null>;
  updateStatus(id: string, status: string, result?: any, error?: string): Promise<BrowserAction | null>;
}
