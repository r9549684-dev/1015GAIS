import { HMMStateRepository } from "../adapters/repositories/HMMStateRepository";
import { MouseMovementRepository } from "../adapters/repositories/MouseMovementRepository";
import { BrowserActionRepository } from "../adapters/repositories/BrowserActionRepository";
import { AIDecisionLogRepository } from "../adapters/repositories/AIDecisionLogRepository";
import { ParsingTaskRepository } from "../adapters/repositories/ParsingTaskRepository";
import { ParsingResultRepository } from "../adapters/repositories/ParsingResultRepository";
import { MistralService } from "./services/MistralService";
import { PlaywrightService } from "./services/PlaywrightService";
import { HMMEngineWithPersistence } from "./services/HMMEngineWithPersistence";
import { ExecuteAIParsingUseCase } from "../application/use-cases/ExecuteAIParsingUseCase";
import { GenerateHumanMouseMovementUseCase } from "../application/use-cases/GenerateHumanMouseMovementUseCase";
import { GetHMMStateUseCase } from "../application/use-cases/GetHMMStateUseCase";
import { GetBrowserActionsUseCase } from "../application/use-cases/GetBrowserActionsUseCase";
import { GetMouseMovementsUseCase } from "../application/use-cases/GetMouseMovementsUseCase";
import { GetAIDecisionsUseCase } from "../application/use-cases/GetAIDecisionsUseCase";

export class DependencyContainer {
  // Repositories (singleton)
  private static hmmRepo = new HMMStateRepository();
  private static mouseRepo = new MouseMovementRepository();
  private static actionRepo = new BrowserActionRepository();
  private static aiLogRepo = new AIDecisionLogRepository();
  private static taskRepo = new ParsingTaskRepository();
  private static resultRepo = new ParsingResultRepository();

  // Services (singleton)
  private static mistralService = new MistralService(
    process.env.MISTRAL_API_URL || "http://89.208.107.67:8000"
  );
  private static playwrightService = new PlaywrightService();
  private static hmmEngine = new HMMEngineWithPersistence(this.hmmRepo);

  // Use Cases
  static getExecuteAIParsingUseCase(): ExecuteAIParsingUseCase {
    return new ExecuteAIParsingUseCase(
      this.taskRepo,
      this.resultRepo,
      this.mistralService,
      this.playwrightService,
      this.hmmEngine
    );
  }

  static getGenerateHumanMouseMovementUseCase(): GenerateHumanMouseMovementUseCase {
    return new GenerateHumanMouseMovementUseCase(this.mistralService);
  }

  static getGetHMMStateUseCase(): GetHMMStateUseCase {
    return new GetHMMStateUseCase(this.hmmRepo);
  }

  static getGetBrowserActionsUseCase(): GetBrowserActionsUseCase {
    return new GetBrowserActionsUseCase(this.actionRepo);
  }

  static getGetMouseMovementsUseCase(): GetMouseMovementsUseCase {
    return new GetMouseMovementsUseCase(this.mouseRepo);
  }

  static getGetAIDecisionsUseCase(): GetAIDecisionsUseCase {
    return new GetAIDecisionsUseCase(this.aiLogRepo);
  }

  static getMistralService(): MistralService {
    return this.mistralService;
  }

  static getPlaywrightService(): PlaywrightService {
    return this.playwrightService;
  }
}
