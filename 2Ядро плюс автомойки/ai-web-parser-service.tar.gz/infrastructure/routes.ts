import { Router } from "express";
import { ParserController } from "../adapters/controllers/ParserController";
import { AIParserController } from "../adapters/controllers/AIParserController";
import { DependencyContainer } from "./DependencyInjection";

const router = Router();
const controller = new ParserController();

// Create AI Parser controller with injected dependencies
const aiController = new AIParserController(
  DependencyContainer.getExecuteAIParsingUseCase(),
  DependencyContainer.getGenerateHumanMouseMovementUseCase(),
  DependencyContainer.getGetHMMStateUseCase(),
  DependencyContainer.getGetBrowserActionsUseCase(),
  DependencyContainer.getGetMouseMovementsUseCase(),
  DependencyContainer.getGetAIDecisionsUseCase(),
  DependencyContainer.getMistralService(),
  DependencyContainer.getPlaywrightService()
);

// Health check
router.get("/health", controller.healthCheck);
router.get("/ai/health", aiController.healthCheck);

// Task management
router.post("/tasks", controller.createTask);
router.get("/tasks/:taskId", controller.getTaskStatus);
router.post("/tasks/:taskId/parse", controller.parseTask);

// AI Parsing with HMM
router.post("/tasks/:taskId/ai-parse", aiController.executeAIParsing);

// Human Mouse Movement
router.post("/mouse/generate", aiController.generateMouseMovement);

// HMM State & Analytics
router.get("/tasks/:taskId/hmm", aiController.getHMMState);
router.get("/tasks/:taskId/actions", aiController.getBrowserActions);
router.get("/tasks/:taskId/movements", aiController.getMouseMovements);
router.get("/tasks/:taskId/ai-decisions", aiController.getAIDecisions);

export { router as parserRouter };
