import { chromium, type Browser, type Page, type BrowserContext } from "playwright";
import type { IPlaywrightGateway, PlaywrightPage } from "../../adapters/gateways/IPlaywrightGateway";
import type { BrowserActionEntity } from "../../domain/entities/BrowserAction";
import type { MouseMovementEntity } from "../../domain/entities/MouseMovement";

export class PlaywrightService implements IPlaywrightGateway {
  private browser: Browser | null = null;
  private context: BrowserContext | null = null;
  private page: Page | null = null;

  async initialize(options?: {
    headless?: boolean;
    userAgent?: string;
    viewport?: { width: number; height: number };
  }): Promise<void> {
    this.browser = await chromium.launch({
      headless: options?.headless ?? true,
      args: [
        '--disable-blink-features=AutomationControlled',
        '--disable-dev-shm-usage',
        '--no-sandbox',
      ],
    });

    this.context = await this.browser.newContext({
      viewport: options?.viewport || { width: 1920, height: 1080 },
      userAgent: options?.userAgent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    });

    this.page = await this.context.newPage();

    await this.page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });
    });
  }

  async executeAction(
    action: BrowserActionEntity,
    mouseMovement?: MouseMovementEntity
  ): Promise<any> {
    if (!this.page) {
      throw new Error("Browser not initialized. Call initialize() first.");
    }

    if (mouseMovement && action.actionType !== 'wait' && action.actionType !== 'screenshot') {
      await this.executeMouseMovement(mouseMovement);
    }

    switch (action.actionType) {
      case 'navigate':
        if (!action.context.url) throw new Error("URL required for navigate");
        return await this.navigate(action.context.url);

      case 'click':
        if (!action.context.selector) throw new Error("Selector required for click");
        if (action.executeWithHMM && mouseMovement) {
          return await this.clickWithHumanMouse(action.context.selector, mouseMovement);
        }
        return await this.page.click(action.context.selector);

      case 'type':
        if (!action.context.selector || !action.context.text) {
          throw new Error("Selector and text required for type");
        }
        return await this.typeText(action.context.selector, action.context.text, action.executeWithHMM);

      case 'scroll':
        const scrollAmount = action.context.scrollAmount ?? 500;
        return await this.scroll(scrollAmount, false);

      case 'wait':
        const waitTime = action.context.waitTime ?? 1000;
        await new Promise(resolve => setTimeout(resolve, waitTime));
        return { success: true };

      case 'hover':
        if (!action.context.selector) throw new Error("Selector required for hover");
        return await this.page.hover(action.context.selector);

      case 'screenshot':
        return await this.screenshot(false);

      case 'extract_html':
        return await this.getHTML();

      default:
        throw new Error(`Unknown action type: ${action.actionType}`);
    }
  }

  async navigate(url: string): Promise<PlaywrightPage> {
    if (!this.page) throw new Error("Page not initialized");
    
    const response = await this.page.goto(url, { 
      waitUntil: 'domcontentloaded',
      timeout: 30000 
    });
    
    const title = await this.page.title();
    const html = await this.page.content();
    
    return {
      url: this.page.url(),
      title,
      html,
    };
  }

  async clickWithHumanMouse(
    selector: string,
    mouseParams: MouseMovementEntity
  ): Promise<void> {
    if (!this.page) throw new Error("Page not initialized");
    
    await this.executeMouseMovement(mouseParams);
    
    await this.page.click(selector, { timeout: 10000 });
  }

  async scroll(amount: number, smooth: boolean = false): Promise<void> {
    if (!this.page) throw new Error("Page not initialized");
    
    if (smooth) {
      await this.page.evaluate((amt) => {
        window.scrollBy({ top: amt, behavior: 'smooth' });
      }, amount);
      await new Promise(resolve => setTimeout(resolve, 500));
    } else {
      await this.page.evaluate((amt) => {
        window.scrollBy(0, amt);
      }, amount);
    }
  }

  async typeText(selector: string, text: string, humanLike: boolean = false): Promise<void> {
    if (!this.page) throw new Error("Page not initialized");
    
    await this.page.fill(selector, '');
    
    if (humanLike) {
      for (const char of text) {
        await this.page.type(selector, char, { delay: 50 + Math.random() * 100 });
      }
    } else {
      await this.page.fill(selector, text);
    }
  }

  async getHTML(): Promise<string> {
    if (!this.page) throw new Error("Page not initialized");
    return await this.page.content();
  }

  async screenshot(fullPage: boolean = false): Promise<Buffer> {
    if (!this.page) throw new Error("Page not initialized");
    return await this.page.screenshot({ type: 'png', fullPage });
  }

  async waitForSelector(selector: string, timeout: number = 30000): Promise<boolean> {
    if (!this.page) throw new Error("Page not initialized");
    
    try {
      await this.page.waitForSelector(selector, { timeout });
      return true;
    } catch {
      return false;
    }
  }

  async close(): Promise<void> {
    if (this.page) {
      await this.page.close();
      this.page = null;
    }
    if (this.context) {
      await this.context.close();
      this.context = null;
    }
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }

  async healthCheck(): Promise<{ status: string }> {
    try {
      const browser = await chromium.launch({ headless: true });
      await browser.close();
      return { status: "ok" };
    } catch (error) {
      return { status: "error" };
    }
  }

  private async executeMouseMovement(movement: MouseMovementEntity): Promise<void> {
    if (!this.page) throw new Error("Page not initialized");

    const bezierPoints = movement.bezierPoints;
    
    for (let i = 0; i < bezierPoints.length; i++) {
      const point = bezierPoints[i];
      
      await this.page.mouse.move(point.x, point.y);
      
      if (movement.params.pauseProbability && Math.random() < movement.params.pauseProbability) {
        const pauseDuration = 50 + Math.random() * 150;
        await new Promise(resolve => setTimeout(resolve, pauseDuration));
      }
      
      const baseDelay = 1000 / movement.params.speed;
      const jitterDelay = baseDelay * (1 + (Math.random() - 0.5) * movement.params.jitter);
      await new Promise(resolve => setTimeout(resolve, jitterDelay));
    }

    if (movement.params.overshoot > 0 && Math.random() < 0.3) {
      const lastPoint = bezierPoints[bezierPoints.length - 1];
      const overshootX = lastPoint.x + (Math.random() - 0.5) * movement.params.overshoot;
      const overshootY = lastPoint.y + (Math.random() - 0.5) * movement.params.overshoot;
      
      await this.page.mouse.move(overshootX, overshootY);
      await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 50));
      await this.page.mouse.move(lastPoint.x, lastPoint.y);
    }
  }
}
