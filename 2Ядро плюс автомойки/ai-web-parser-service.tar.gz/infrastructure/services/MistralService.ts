import type { IMistralGateway, MistralParsingAnalysis } from "../../adapters/gateways/IMistralGateway";
import type { MouseMovementParams } from "../../domain/entities/MouseMovement";

export class MistralService implements IMistralGateway {
  private ollamaUrl: string;
  private model: string;
  private timeout: number;

  constructor(
    ollamaUrl: string = process.env.OLLAMA_URL || "http://89.208.107.67:8000",
    model: string = "mistral",
    timeout: number = 10000
  ) {
    this.ollamaUrl = ollamaUrl;
    this.model = model;
    this.timeout = timeout;
  }

  async generateMouseMovementParams(context: {
    actionType: string;
    targetElement?: string;
    distance: number;
  }): Promise<MouseMovementParams> {
    const prompt = this.buildMouseMovementPrompt(context);

    try {
      const response = await this.callOllama(prompt);
      const params = this.parseMouseParams(response);
      return params;
    } catch (error) {
      console.error("Mistral API error, using fallback params:", error);
      return this.getFallbackMouseParams(context);
    }
  }

  async analyzeHTMLStructure(htmlSample: string, targetDataType: string): Promise<MistralParsingAnalysis> {
    const prompt = `Analyze this HTML and suggest CSS selectors to extract ${targetDataType}:

HTML:
${htmlSample}

Respond in JSON format:
{
  "selectors": ["selector1", "selector2"],
  "extractionStrategy": "description",
  "confidence": 0.8
}`;

    try {
      const response = await this.callOllama(prompt);
      const parsed = JSON.parse(response);
      
      return {
        selectors: parsed.selectors || [],
        extractionStrategy: parsed.extractionStrategy || "default",
        confidence: parsed.confidence || 0.5,
      };
    } catch (error) {
      console.error("Mistral analysis error:", error);
      // Fallback селекторы
      return {
        selectors: ["article", ".content", "main", "p"],
        extractionStrategy: "generic content extraction",
        confidence: 0.3,
      };
    }
  }

  async generateExtractionStrategy(context: {
    url: string;
    sourceType: string;
    htmlStructure: string;
  }): Promise<string> {
    const prompt = `Generate extraction strategy for:
URL: ${context.url}
Type: ${context.sourceType}
HTML: ${context.htmlStructure.substring(0, 2000)}

Provide step-by-step extraction strategy.`;

    try {
      const response = await this.callOllama(prompt);
      return response;
    } catch (error) {
      return "Use generic selectors: article, .content, main, p. Extract text content.";
    }
  }

  async decideNextAction(context: {
    currentState: string;
    pageContent: string;
    extractedSoFar: number;
    targetCount: number;
  }): Promise<{ action: string; reasoning: string }> {
    const prompt = `Current state: ${context.currentState}
Extracted: ${context.extractedSoFar}/${context.targetCount}

What should be the next action? Respond in JSON:
{
  "action": "scroll|click|extract|complete",
  "reasoning": "explanation"
}`;

    try {
      const response = await this.callOllama(prompt);
      const parsed = JSON.parse(response);
      return {
        action: parsed.action || "extract",
        reasoning: parsed.reasoning || "Continue extraction",
      };
    } catch (error) {
      return {
        action: "extract",
        reasoning: "Default extraction action",
      };
    }
  }

  async healthCheck(): Promise<{ status: string; model: string }> {
    try {
      const response = await fetch(`${this.ollamaUrl}/api/tags`, {
        method: "GET",
        signal: AbortSignal.timeout(5000),
      });

      if (response.ok) {
        const data = await response.json();
        return {
          status: "healthy",
          model: data.models?.find((m: any) => m.name === this.model)?.name || "unknown",
        };
      }

      return { status: "unhealthy", model: "unknown" };
    } catch (error) {
      return { status: "unhealthy", model: "unknown" };
    }
  }

  private async callOllama(prompt: string): Promise<string> {
    const response = await fetch(`${this.ollamaUrl}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: this.model,
        prompt,
        stream: false,
      }),
      signal: AbortSignal.timeout(this.timeout),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status}`);
    }

    const data = await response.json();
    return data.response || "";
  }

  private buildMouseMovementPrompt(context: {
    actionType: string;
    targetElement?: string;
    distance: number;
  }): string {
    return `Generate human-like mouse movement parameters for ${context.actionType} action.
Target: ${context.targetElement || "element"}
Distance: ${context.distance}px

Respond in JSON format:
{
  "jitter": 2.5,
  "speed": 0.5,
  "curvature": 0.3,
  "pauseProbability": 0.15,
  "overshoot": 5
}

Rules:
- jitter: 1-5 (natural tremor)
- speed: 0.3-0.8 px/ms
- curvature: 0.1-0.5 (Bezier curve)
- pauseProbability: 0.1-0.3
- overshoot: 0-10px`;
  }

  private parseMouseParams(response: string): MouseMovementParams {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          jitter: this.clamp(parsed.jitter || 3, 1, 10),
          speed: this.clamp(parsed.speed || 0.5, 0.1, 10),
          curvature: this.clamp(parsed.curvature || 0.3, 0, 1),
          pauseProbability: this.clamp(parsed.pauseProbability || 0.15, 0, 1),
          overshoot: this.clamp(parsed.overshoot || 5, 0, 50),
        };
      }
    } catch (error) {
      console.error("Failed to parse mouse params:", error);
    }

    return this.getFallbackMouseParams({
      actionType: "default",
      distance: 100,
    });
  }

  private getFallbackMouseParams(context: {
    actionType: string;
    distance: number;
  }): MouseMovementParams {
    // Эвристика на основе расстояния
    const baseJitter = 2.5 + Math.random() * 1.5;
    const baseSpeed = context.distance > 300 ? 0.6 : 0.4;

    return {
      jitter: baseJitter,
      speed: baseSpeed + Math.random() * 0.2,
      curvature: 0.2 + Math.random() * 0.2,
      pauseProbability: 0.1 + Math.random() * 0.1,
      overshoot: Math.random() * 8,
    };
  }

  private clamp(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, value));
  }
}
