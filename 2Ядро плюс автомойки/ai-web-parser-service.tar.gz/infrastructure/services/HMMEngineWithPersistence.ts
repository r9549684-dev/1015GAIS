import type { IHMMGateway } from "../../adapters/gateways/IHMMGateway";
import { HMMStateEntity, type HMMStateType } from "../../domain/entities/HMMState";
import type { IHMMStateRepository } from "../../application/ports/IHMMStateRepository";

export class HMMEngineWithPersistence implements IHMMGateway {
  constructor(private hmmRepo: IHMMStateRepository) {}

  async initializeState(taskId: string): Promise<HMMStateEntity> {
    const stateData = HMMStateEntity.create(taskId);
    
    const saved = await this.hmmRepo.create({
      taskId: stateData.taskId,
      currentState: stateData.currentState,
      previousState: stateData.previousState,
      transitionProbabilities: stateData.transitionProbabilities as any,
      observations: stateData.observations as any,
    });

    return this.toEntity(saved);
  }

  async getCurrentState(taskId: string): Promise<HMMStateEntity | null> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (!state) return null;
    return this.toEntity(state);
  }

  async transition(taskId: string, newState: HMMStateType): Promise<void> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const entity = this.toEntity(state);
    entity.transition(newState);

    await this.hmmRepo.update(state.id, {
      currentState: entity.currentState,
      previousState: entity.previousState,
      transitionProbabilities: entity.transitionProbabilities as any,
    });
  }

  async addObservation(
    taskId: string,
    observation: {
      action: string;
      success: boolean;
      metrics?: any;
    }
  ): Promise<void> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const entity = this.toEntity(state);
    entity.addObservation({
      timestamp: new Date(),
      action: observation.action,
      success: observation.success,
      metrics: observation.metrics,
    });

    await this.hmmRepo.update(state.id, {
      observations: entity.observations as any,
      transitionProbabilities: entity.transitionProbabilities as any,
    });
  }

  async getNextStateRecommendation(taskId: string): Promise<{
    nextState: HMMStateType;
    confidence: number;
    reasoning: string;
  }> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const entity = this.toEntity(state);
    const next = entity.getNextStateWithProbability();
    
    if (!next) {
      return {
        nextState: "failed",
        confidence: 0,
        reasoning: "No valid transitions available",
      };
    }

    const reasoning = this.generateReasoning(entity.currentState, next.state, next.probability);

    return {
      nextState: next.state,
      confidence: next.probability,
      reasoning,
    };
  }

  async evaluateStrategy(taskId: string): Promise<{
    successRate: number;
    shouldAdapt: boolean;
    recommendation: string;
  }> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const entity = this.toEntity(state);
    const successRate = entity.getSuccessRate();
    const shouldAdapt = successRate < 0.6;

    let recommendation = "Strategy is performing well";
    if (shouldAdapt) {
      recommendation = successRate < 0.3
        ? "Poor performance. Consider completely changing approach."
        : "Below optimal. Try refining selectors or adjusting timing.";
    }

    return {
      successRate,
      shouldAdapt,
      recommendation,
    };
  }

  async reset(taskId: string): Promise<void> {
    const state = await this.hmmRepo.getByTaskId(taskId);
    if (state) {
      const entity = this.toEntity(state);
      entity.currentState = "initial";
      entity.previousState = null;
      entity.observations = [];
      entity.transitionProbabilities = HMMStateEntity.getInitialProbabilities();

      await this.hmmRepo.update(state.id, {
        currentState: "initial",
        previousState: null,
        observations: [],
        transitionProbabilities: HMMStateEntity.getInitialProbabilities() as any,
      });
    }
  }

  private toEntity(dbState: any): HMMStateEntity {
    return new HMMStateEntity(
      dbState.id,
      dbState.taskId,
      dbState.currentState as HMMStateType,
      dbState.previousState as HMMStateType | null,
      dbState.transitionProbabilities || [],
      dbState.observations || [],
      dbState.createdAt,
      dbState.updatedAt
    );
  }

  private generateReasoning(
    currentState: HMMStateType,
    nextState: HMMStateType,
    probability: number
  ): string {
    const transitions: Record<string, string> = {
      "initial->exploring": "Begin exploring page structure",
      "exploring->extracting": "Structure analyzed, ready to extract data",
      "exploring->refining": "Need to refine selectors before extraction",
      "extracting->refining": "Extraction quality low, refining approach",
      "extracting->completed": "Sufficient data extracted successfully",
      "refining->extracting": "Selectors refined, retry extraction",
      "refining->completed": "Quality improved, task complete",
    };

    const key = `${currentState}->${nextState}`;
    const baseReason = transitions[key] || `Transition from ${currentState} to ${nextState}`;
    
    return `${baseReason} (confidence: ${(probability * 100).toFixed(1)}%)`;
  }
}
