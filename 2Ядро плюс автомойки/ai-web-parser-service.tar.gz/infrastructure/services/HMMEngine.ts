import type { IHMMGateway } from "../../adapters/gateways/IHMMGateway";
import { HMMStateEntity, type HMMStateType } from "../../domain/entities/HMMState";

interface HMMStateStore {
  [taskId: string]: HMMStateEntity;
}

export class HMMEngine implements IHMMGateway {
  private states: HMMStateStore = {};

  async initializeState(taskId: string): Promise<HMMStateEntity> {
    const stateData = HMMStateEntity.create(taskId);
    
    const state = new HMMStateEntity(
      this.generateId(),
      stateData.taskId,
      stateData.currentState,
      stateData.previousState,
      stateData.transitionProbabilities,
      stateData.observations,
      new Date(),
      new Date()
    );

    this.states[taskId] = state;
    return state;
  }

  async getCurrentState(taskId: string): Promise<HMMStateEntity | null> {
    return this.states[taskId] || null;
  }

  async transition(taskId: string, newState: HMMStateType): Promise<void> {
    const state = this.states[taskId];
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    state.transition(newState);
  }

  async addObservation(
    taskId: string,
    observation: {
      action: string;
      success: boolean;
      metrics?: any;
    }
  ): Promise<void> {
    const state = this.states[taskId];
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    state.addObservation({
      timestamp: new Date(),
      action: observation.action,
      success: observation.success,
      metrics: observation.metrics,
    });
  }

  async getNextStateRecommendation(taskId: string): Promise<{
    nextState: HMMStateType;
    confidence: number;
    reasoning: string;
  }> {
    const state = this.states[taskId];
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const next = state.getNextStateWithProbability();
    if (!next) {
      return {
        nextState: "failed",
        confidence: 0,
        reasoning: "No valid transitions available",
      };
    }

    const reasoning = this.generateReasoning(state.currentState, next.state, next.probability);

    return {
      nextState: next.state,
      confidence: next.probability,
      reasoning,
    };
  }

  async evaluateStrategy(taskId: string): Promise<{
    successRate: number;
    shouldAdapt: boolean;
    recommendation: string;
  }> {
    const state = this.states[taskId];
    if (!state) {
      throw new Error(`HMM state not found for task: ${taskId}`);
    }

    const successRate = state.getSuccessRate();
    const shouldAdapt = successRate < 0.6;

    let recommendation = "Strategy is performing well";
    if (shouldAdapt) {
      recommendation = successRate < 0.3
        ? "Poor performance. Consider completely changing approach."
        : "Below optimal. Try refining selectors or adjusting timing.";
    }

    return {
      successRate,
      shouldAdapt,
      recommendation,
    };
  }

  async reset(taskId: string): Promise<void> {
    const state = this.states[taskId];
    if (state) {
      state.currentState = "initial";
      state.previousState = null;
      state.observations = [];
      state.transitionProbabilities = HMMStateEntity.getInitialProbabilities();
      state.updatedAt = new Date();
    }
  }

  private generateReasoning(
    currentState: HMMStateType,
    nextState: HMMStateType,
    probability: number
  ): string {
    const transitions: Record<string, string> = {
      "initial->exploring": "Begin exploring page structure",
      "exploring->extracting": "Structure analyzed, ready to extract data",
      "exploring->refining": "Need to refine selectors before extraction",
      "extracting->refining": "Extraction quality low, refining approach",
      "extracting->completed": "Sufficient data extracted successfully",
      "refining->extracting": "Selectors refined, retry extraction",
      "refining->completed": "Quality improved, task complete",
    };

    const key = `${currentState}->${nextState}`;
    const baseReason = transitions[key] || `Transition from ${currentState} to ${nextState}`;
    
    return `${baseReason} (confidence: ${(probability * 100).toFixed(1)}%)`;
  }

  private generateId(): string {
    return `hmm_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  }
}
