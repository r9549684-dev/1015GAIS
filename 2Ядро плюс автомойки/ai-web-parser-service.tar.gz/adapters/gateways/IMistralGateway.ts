import type { MouseMovementParams } from "../../domain/entities/MouseMovement";

export interface MistralParsingAnalysis {
  selectors: string[];
  extractionStrategy: string;
  confidence: number;
}

export interface MistralMouseParams {
  jitter: number;
  speed: number;
  curvature: number;
  pauseProbability: number;
  overshoot: number;
}

export interface IMistralGateway {
  /**
   * Генерирует параметры человекоподобного движения мыши
   */
  generateMouseMovementParams(context: {
    actionType: string;
    targetElement?: string;
    distance: number;
  }): Promise<MouseMovementParams>;

  /**
   * Анализирует HTML структуру и предлагает селекторы
   */
  analyzeHTMLStructure(htmlSample: string, targetDataType: string): Promise<MistralParsingAnalysis>;

  /**
   * Генерирует стратегию извлечения данных
   */
  generateExtractionStrategy(context: {
    url: string;
    sourceType: string;
    htmlStructure: string;
  }): Promise<string>;

  /**
   * Определяет следующее действие на основе текущего состояния
   */
  decideNextAction(context: {
    currentState: string;
    pageContent: string;
    extractedSoFar: number;
    targetCount: number;
  }): Promise<{
    action: string;
    reasoning: string;
  }>;

  /**
   * Health check Mistral сервиса
   */
  healthCheck(): Promise<{ status: string; model: string }>;
}
