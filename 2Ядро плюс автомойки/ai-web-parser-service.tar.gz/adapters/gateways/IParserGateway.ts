import type { ContentType } from "../../domain/entities/ParsingResult";
import type { ParsingOptions } from "../../domain/entities/ParsingTask";

export interface ParsedContent {
  content: string;
  contentType: ContentType;
  metadata: {
    title?: string;
    description?: string;
    author?: string;
    publishedDate?: string;
    modifiedDate?: string;
    language?: string;
    keywords?: string[];
    links?: string[];
    images?: string[];
  };
  extractedData: {
    headings?: { level: number; text: string }[];
    codeBlocks?: { language: string; code: string }[];
    tables?: any[][];
    lists?: string[][];
    structuredData?: any;
  };
}

export interface IParserGateway {
  parseUrl(url: string, options?: any): Promise<ParsedContent>;
  healthCheck(): Promise<{ status: string; message?: string }>;
}
