import type { HMMStateEntity, HMMStateType } from "../../domain/entities/HMMState";

export interface HMMTransitionRecommendation {
  nextState: HMMStateType;
  confidence: number;
  reasoning: string;
}

export interface IHMMGateway {
  /**
   * Инициализирует HMM состояние для задачи
   */
  initializeState(taskId: string): Promise<HMMStateEntity>;

  /**
   * Получить текущее состояние
   */
  getCurrentState(taskId: string): Promise<HMMStateEntity | null>;

  /**
   * Переход в новое состояние
   */
  transition(taskId: string, newState: HMMStateType): Promise<void>;

  /**
   * Добавить наблюдение (результат действия)
   */
  addObservation(
    taskId: string,
    observation: {
      action: string;
      success: boolean;
      metrics?: any;
    }
  ): Promise<void>;

  /**
   * Получить рекомендацию следующего состояния на основе вероятностей
   */
  getNextStateRecommendation(taskId: string): Promise<HMMTransitionRecommendation>;

  /**
   * Оценить успешность текущей стратегии
   */
  evaluateStrategy(taskId: string): Promise<{
    successRate: number;
    shouldAdapt: boolean;
    recommendation: string;
  }>;

  /**
   * Сброс состояния (для повторной попытки)
   */
  reset(taskId: string): Promise<void>;
}
