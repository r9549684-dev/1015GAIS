export interface IParsingLogger {
  info(message: string, details?: Record<string, any>): Promise<void>;
  warning(message: string, details?: Record<string, any>): Promise<void>;
  error(message: string, details?: Record<string, any>): Promise<void>;
  debug(message: string, details?: Record<string, any>): Promise<void>;
}
