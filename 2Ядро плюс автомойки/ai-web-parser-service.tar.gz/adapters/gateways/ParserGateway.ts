import type { IParserGateway, ParsedContent } from "./IParserGateway";
import type { ParsingOptions } from "../../domain/entities/ParsingTask";
import * as cheerio from "cheerio";

export class ParserGateway implements IParserGateway {
  private readonly externalParserUrl: string;

  constructor(externalParserUrl?: string) {
    this.externalParserUrl =
      externalParserUrl || process.env.PARSER_API_URL || "http://89.208.107.67:8001";
  }

  async parseUrl(url: string, options?: ParsingOptions): Promise<ParsedContent> {
    try {
      // Try external parser first if available
      if (await this.isExternalParserAvailable()) {
        return await this.parseWithExternalParser(url, options);
      }

      // Fallback to built-in parser
      return await this.parseWithBuiltInParser(url, options);
    } catch (error: any) {
      console.error("Parsing failed:", error);
      throw new Error(`Failed to parse URL: ${error.message}`);
    }
  }

  async healthCheck(): Promise<{ status: string; message?: string }> {
    try {
      const response = await fetch(`${this.externalParserUrl}/`, {
        method: "GET",
        signal: AbortSignal.timeout(5000),
      });

      if (!response.ok) {
        return { status: "unhealthy", message: "External parser not responding" };
      }

      return { status: "healthy", message: "External parser available" };
    } catch (error) {
      // External parser unavailable, check built-in
      return {
        status: "partial",
        message: "External parser unavailable, using built-in parser",
      };
    }
  }

  private async isExternalParserAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.externalParserUrl}/`, {
        method: "GET",
        signal: AbortSignal.timeout(3000),
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  private async parseWithExternalParser(
    url: string,
    options?: ParsingOptions
  ): Promise<ParsedContent> {
    // Create parsing task
    const createResponse = await fetch(`${this.externalParserUrl}/parse/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });

    if (!createResponse.ok) {
      throw new Error(`External parser error: ${createResponse.status}`);
    }

    const taskData = await createResponse.json();
    const taskId = taskData.task_id;

    // Poll for results
    const maxAttempts = 30;
    let attempts = 0;

    while (attempts < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const statusResponse = await fetch(`${this.externalParserUrl}/status/${taskId}`);
      const statusData = await statusResponse.json();

      if (statusData.status === "SUCCESS" || statusData.status === "completed") {
        return this.convertExternalParserResult(statusData.result);
      }

      if (statusData.status === "FAILURE" || statusData.status === "failed") {
        throw new Error("External parser failed");
      }

      attempts++;
    }

    throw new Error("Parsing timeout");
  }

  private async parseWithBuiltInParser(
    url: string,
    options?: ParsingOptions
  ): Promise<ParsedContent> {
    // Fetch HTML
    const response = await fetch(url, {
      headers: options?.headers || {},
      signal: AbortSignal.timeout(options?.timeout || 30000),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    // Extract metadata
    const metadata = {
      title: $("title").text() || $('meta[property="og:title"]').attr("content"),
      description:
        $('meta[name="description"]').attr("content") ||
        $('meta[property="og:description"]').attr("content"),
      author: $('meta[name="author"]').attr("content"),
      keywords: $('meta[name="keywords"]')
        .attr("content")
        ?.split(",")
        .map((k) => k.trim()),
      links: $("a")
        .map((_, el) => $(el).attr("href"))
        .get()
        .filter((href) => href && href.startsWith("http")),
      images: $("img")
        .map((_, el) => $(el).attr("src"))
        .get()
        .filter((src) => src && src.startsWith("http")),
    };

    // Extract content
    $("script, style, nav, footer, header").remove();
    const content = $("body").text().trim();

    // Extract code blocks
    const codeBlocks = $("pre code, code")
      .map((_, el) => {
        const $el = $(el);
        const language = $el.attr("class")?.match(/language-(\w+)/)?.[1] || "unknown";
        return { language, code: $el.text() };
      })
      .get();

    // Extract headings
    const headings = $("h1, h2, h3, h4, h5, h6")
      .map((_, el) => {
        const $el = $(el);
        return {
          level: parseInt($el[0].tagName.substring(1)),
          text: $el.text().trim(),
        };
      })
      .get();

    return {
      content,
      contentType: "html",
      metadata,
      extractedData: {
        headings,
        codeBlocks,
        tables: [],
        lists: [],
      },
    };
  }

  private convertExternalParserResult(result: any): ParsedContent {
    return {
      content: result.data?.content || JSON.stringify(result.data),
      contentType: "json",
      metadata: {
        title: result.data?.title,
        links: result.data?.links || [],
      },
      extractedData: {
        headings: [],
        codeBlocks: [],
        tables: [],
        lists: [],
      },
    };
  }
}
