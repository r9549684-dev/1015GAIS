import { db } from "../../infrastructure/storage";
import { parsingLogs } from "../../shared/schema";
import type { IParsingLogger } from "./IParsingLogger";

export class ParsingLogger implements IParsingLogger {
  async info(message: string, details?: Record<string, any>): Promise<void> {
    await this.log("info", message, details);
  }

  async warning(message: string, details?: Record<string, any>): Promise<void> {
    await this.log("warning", message, details);
  }

  async error(message: string, details?: Record<string, any>): Promise<void> {
    await this.log("error", message, details);
    console.error(`[Parser Error] ${message}`, details);
  }

  async debug(message: string, details?: Record<string, any>): Promise<void> {
    await this.log("debug", message, details);
  }

  private async log(
    level: string,
    message: string,
    details?: Record<string, any>
  ): Promise<void> {
    try {
      await db.insert(parsingLogs).values({
        level,
        message,
        details: details || null,
        taskId: details?.taskId || null,
      });
    } catch (error) {
      console.error("Failed to write log:", error);
    }
  }
}
