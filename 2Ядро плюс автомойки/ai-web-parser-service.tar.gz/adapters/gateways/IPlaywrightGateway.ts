import type { BrowserActionEntity } from "../../domain/entities/BrowserAction";
import type { MouseMovementEntity } from "../../domain/entities/MouseMovement";

export interface PlaywrightPage {
  url: string;
  title: string;
  html: string;
  screenshot?: Buffer;
}

export interface IPlaywrightGateway {
  /**
   * Инициализирует браузер (Chromium)
   */
  initialize(options?: {
    headless?: boolean;
    userAgent?: string;
    viewport?: { width: number; height: number };
  }): Promise<void>;

  /**
   * Выполняет действие в браузере
   */
  executeAction(action: BrowserActionEntity, mouseMovement?: MouseMovementEntity): Promise<any>;

  /**
   * Навигация на URL
   */
  navigate(url: string): Promise<PlaywrightPage>;

  /**
   * Клик по элементу с человекоподобным движением мыши
   */
  clickWithHumanMouse(
    selector: string,
    mouseParams: MouseMovementEntity
  ): Promise<void>;

  /**
   * Скролл страницы
   */
  scroll(amount: number, smooth?: boolean): Promise<void>;

  /**
   * Ввод текста с задержками между символами
   */
  typeText(selector: string, text: string, humanLike?: boolean): Promise<void>;

  /**
   * Получение HTML контента
   */
  getHTML(): Promise<string>;

  /**
   * Скриншот страницы
   */
  screenshot(fullPage?: boolean): Promise<Buffer>;

  /**
   * Ожидание загрузки элемента
   */
  waitForSelector(selector: string, timeout?: number): Promise<boolean>;

  /**
   * Закрытие браузера
   */
  close(): Promise<void>;

  /**
   * Проверка доступности Playwright
   */
  healthCheck(): Promise<{ status: string }>;
}
