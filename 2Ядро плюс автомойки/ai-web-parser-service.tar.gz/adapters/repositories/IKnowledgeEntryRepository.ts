import type { KnowledgeEntry, InsertKnowledgeEntry } from "../../shared/schema";

export interface IKnowledgeEntryRepository {
  create(entry: Omit<InsertKnowledgeEntry, "id" | "createdAt" | "updatedAt">): Promise<KnowledgeEntry>;
  getById(id: string): Promise<KnowledgeEntry | null>;
  getAll(filters?: {
    sourceType?: string;
    category?: string;
    tags?: string[];
    minRelevanceScore?: number;
  }): Promise<KnowledgeEntry[]>;
  search(query: string, limit?: number): Promise<KnowledgeEntry[]>;
  update(id: string, updates: Partial<KnowledgeEntry>): Promise<void>;
  delete(id: string): Promise<void>;
}
