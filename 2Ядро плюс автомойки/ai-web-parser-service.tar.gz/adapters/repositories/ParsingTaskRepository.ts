import { db } from "../../infrastructure/storage";
import { parsingTasks } from "../../shared/schema";
import type { ParsingTask, InsertParsingTask } from "../../shared/schema";
import type { IParsingTaskRepository } from "./IParsingTaskRepository";
import { eq, and } from "drizzle-orm";

export class ParsingTaskRepository implements IParsingTaskRepository {
  async create(task: Omit<InsertParsingTask, "status" | "createdAt">): Promise<ParsingTask> {
    const [created] = await db
      .insert(parsingTasks)
      .values({
        ...task,
        status: "pending",
      })
      .returning();
    return created;
  }

  async getById(id: string): Promise<ParsingTask | null> {
    const [task] = await db
      .select()
      .from(parsingTasks)
      .where(eq(parsingTasks.id, id))
      .limit(1);
    return task || null;
  }

  async getAll(filters?: { status?: string; sourceType?: string }): Promise<ParsingTask[]> {
    if (!filters || (!filters.status && !filters.sourceType)) {
      return await db.select().from(parsingTasks);
    }

    const conditions = [];
    if (filters.status) {
      conditions.push(eq(parsingTasks.status, filters.status));
    }
    if (filters.sourceType) {
      conditions.push(eq(parsingTasks.sourceType, filters.sourceType));
    }

    if (conditions.length === 1) {
      return await db.select().from(parsingTasks).where(conditions[0]);
    }

    return await db.select().from(parsingTasks).where(and(...conditions));
  }

  async updateStatus(
    id: string,
    status: string,
    startedAt?: Date,
    completedAt?: Date
  ): Promise<void> {
    const updates: any = { status };
    if (startedAt) updates.startedAt = startedAt;
    if (completedAt) updates.completedAt = completedAt;

    await db.update(parsingTasks).set(updates).where(eq(parsingTasks.id, id));
  }

  async delete(id: string): Promise<void> {
    await db.delete(parsingTasks).where(eq(parsingTasks.id, id));
  }
}
