import type { ParsingTask, InsertParsingTask } from "../../shared/schema";

export interface IParsingTaskRepository {
  create(task: Omit<InsertParsingTask, "status" | "createdAt">): Promise<ParsingTask>;
  getById(id: string): Promise<ParsingTask | null>;
  getAll(filters?: { status?: string; sourceType?: string }): Promise<ParsingTask[]>;
  updateStatus(
    id: string,
    status: string,
    startedAt?: Date,
    completedAt?: Date
  ): Promise<void>;
  delete(id: string): Promise<void>;
}
