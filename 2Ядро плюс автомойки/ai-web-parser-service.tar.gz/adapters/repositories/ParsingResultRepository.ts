import { db } from "../../infrastructure/storage";
import { parsingResults } from "../../shared/schema";
import type { ParsingResult, InsertParsingResult } from "../../shared/schema";
import type { IParsingResultRepository } from "./IParsingResultRepository";
import { eq } from "drizzle-orm";

export class ParsingResultRepository implements IParsingResultRepository {
  async create(result: Omit<InsertParsingResult, "id" | "createdAt">): Promise<ParsingResult> {
    const [created] = await db
      .insert(parsingResults)
      .values(result)
      .returning();
    return created;
  }

  async getById(id: string): Promise<ParsingResult | null> {
    const [result] = await db
      .select()
      .from(parsingResults)
      .where(eq(parsingResults.id, id))
      .limit(1);
    return result || null;
  }

  async getByTaskId(taskId: string): Promise<ParsingResult[]> {
    return await db
      .select()
      .from(parsingResults)
      .where(eq(parsingResults.taskId, taskId));
  }

  async delete(id: string): Promise<void> {
    await db.delete(parsingResults).where(eq(parsingResults.id, id));
  }
}
