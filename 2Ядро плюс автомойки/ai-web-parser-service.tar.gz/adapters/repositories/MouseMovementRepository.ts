import { eq, desc } from "drizzle-orm";
import { db } from "../../infrastructure/storage";
import { mouseMovements, type MouseMovement, type InsertMouseMovement } from "../../shared/schema";
import type { IMouseMovementRepository } from "../../application/ports/IMouseMovementRepository";

export class MouseMovementRepository implements IMouseMovementRepository {
  async create(data: InsertMouseMovement): Promise<MouseMovement> {
    const [movement] = await db.insert(mouseMovements).values(data).returning();
    return movement;
  }

  async getByTaskId(taskId: string, limit: number = 100): Promise<MouseMovement[]> {
    return await db
      .select()
      .from(mouseMovements)
      .where(eq(mouseMovements.taskId, taskId))
      .orderBy(desc(mouseMovements.createdAt))
      .limit(limit);
  }

  async getById(id: string): Promise<MouseMovement | null> {
    const [movement] = await db
      .select()
      .from(mouseMovements)
      .where(eq(mouseMovements.id, id))
      .limit(1);
    return movement || null;
  }
}
