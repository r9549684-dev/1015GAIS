import { eq } from "drizzle-orm";
import { db } from "../../infrastructure/storage";
import { hmmStates, type HMMState, type InsertHMMState } from "../../shared/schema";
import type { IHMMStateRepository } from "../../application/ports/IHMMStateRepository";

export class HMMStateRepository implements IHMMStateRepository {
  async create(data: InsertHMMState): Promise<HMMState> {
    const [state] = await db.insert(hmmStates).values(data).returning();
    return state;
  }

  async getByTaskId(taskId: string): Promise<HMMState | null> {
    const [state] = await db
      .select()
      .from(hmmStates)
      .where(eq(hmmStates.taskId, taskId))
      .orderBy(hmmStates.createdAt)
      .limit(1);
    return state || null;
  }

  async update(id: string, data: Partial<InsertHMMState>): Promise<HMMState | null> {
    const [updated] = await db
      .update(hmmStates)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(hmmStates.id, id))
      .returning();
    return updated || null;
  }

  async delete(id: string): Promise<void> {
    await db.delete(hmmStates).where(eq(hmmStates.id, id));
  }
}
