import { db } from "../../infrastructure/storage";
import { knowledgeEntries } from "../../shared/schema";
import type { KnowledgeEntry, InsertKnowledgeEntry } from "../../shared/schema";
import type { IKnowledgeEntryRepository } from "./IKnowledgeEntryRepository";
import { eq, gte, or, ilike, and, arrayContains } from "drizzle-orm";

export class KnowledgeEntryRepository implements IKnowledgeEntryRepository {
  async create(entry: Omit<InsertKnowledgeEntry, "id" | "createdAt" | "updatedAt">): Promise<KnowledgeEntry> {
    const [created] = await db
      .insert(knowledgeEntries)
      .values({
        ...entry,
        relevanceScore: entry.relevanceScore || "0",
      })
      .returning();
    return created;
  }

  async getById(id: string): Promise<KnowledgeEntry | null> {
    const [entry] = await db
      .select()
      .from(knowledgeEntries)
      .where(eq(knowledgeEntries.id, id))
      .limit(1);
    return entry || null;
  }

  async getAll(filters?: {
    sourceType?: string;
    category?: string;
    tags?: string[];
    minRelevanceScore?: number;
  }): Promise<KnowledgeEntry[]> {
    if (!filters) {
      return await db.select().from(knowledgeEntries);
    }

    const conditions = [];
    if (filters.sourceType) {
      conditions.push(eq(knowledgeEntries.sourceType, filters.sourceType));
    }
    if (filters.category) {
      conditions.push(eq(knowledgeEntries.category, filters.category));
    }
    if (filters.tags && filters.tags.length > 0) {
      conditions.push(arrayContains(knowledgeEntries.tags, filters.tags));
    }
    if (filters.minRelevanceScore !== undefined) {
      conditions.push(gte(knowledgeEntries.relevanceScore, filters.minRelevanceScore.toString()));
    }

    if (conditions.length === 0) {
      return await db.select().from(knowledgeEntries);
    }

    if (conditions.length === 1) {
      return await db.select().from(knowledgeEntries).where(conditions[0]);
    }

    return await db.select().from(knowledgeEntries).where(and(...conditions));
  }

  async search(query: string, limit: number = 20): Promise<KnowledgeEntry[]> {
    return await db
      .select()
      .from(knowledgeEntries)
      .where(
        or(
          ilike(knowledgeEntries.content, `%${query}%`),
          ilike(knowledgeEntries.summary, `%${query}%`)
        )
      )
      .limit(limit);
  }

  async update(id: string, updates: Partial<KnowledgeEntry>): Promise<void> {
    await db
      .update(knowledgeEntries)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(knowledgeEntries.id, id));
  }

  async delete(id: string): Promise<void> {
    await db.delete(knowledgeEntries).where(eq(knowledgeEntries.id, id));
  }
}
