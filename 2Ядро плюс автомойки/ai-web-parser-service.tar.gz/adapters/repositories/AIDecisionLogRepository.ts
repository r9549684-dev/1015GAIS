import { eq, desc } from "drizzle-orm";
import { db } from "../../infrastructure/storage";
import { aiDecisionsLog, type AIDecisionLog, type InsertAIDecisionLog } from "../../shared/schema";
import type { IAIDecisionLogRepository } from "../../application/ports/IAIDecisionLogRepository";

export class AIDecisionLogRepository implements IAIDecisionLogRepository {
  async create(data: InsertAIDecisionLog): Promise<AIDecisionLog> {
    const [log] = await db.insert(aiDecisionsLog).values(data).returning();
    return log;
  }

  async getByTaskId(taskId: string, limit: number = 100): Promise<AIDecisionLog[]> {
    return await db
      .select()
      .from(aiDecisionsLog)
      .where(eq(aiDecisionsLog.taskId, taskId))
      .orderBy(desc(aiDecisionsLog.timestamp))
      .limit(limit);
  }

  async getById(id: string): Promise<AIDecisionLog | null> {
    const [log] = await db
      .select()
      .from(aiDecisionsLog)
      .where(eq(aiDecisionsLog.id, id))
      .limit(1);
    return log || null;
  }

  async getByDecisionType(taskId: string, decisionType: string): Promise<AIDecisionLog[]> {
    const { and } = await import("drizzle-orm");
    return await db
      .select()
      .from(aiDecisionsLog)
      .where(and(
        eq(aiDecisionsLog.taskId, taskId),
        eq(aiDecisionsLog.decisionType, decisionType)
      ))
      .orderBy(desc(aiDecisionsLog.timestamp));
  }
}
