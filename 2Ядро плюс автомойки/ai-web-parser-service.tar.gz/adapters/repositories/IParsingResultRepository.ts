import type { ParsingResult, InsertParsingResult } from "../../shared/schema";

export interface IParsingResultRepository {
  create(result: Omit<InsertParsingResult, "id" | "createdAt">): Promise<ParsingResult>;
  getById(id: string): Promise<ParsingResult | null>;
  getByTaskId(taskId: string): Promise<ParsingResult[]>;
  delete(id: string): Promise<void>;
}
