import { eq, desc } from "drizzle-orm";
import { db } from "../../infrastructure/storage";
import { browserActions, type BrowserAction, type InsertBrowserAction } from "../../shared/schema";
import type { IBrowserActionRepository } from "../../application/ports/IBrowserActionRepository";

export class BrowserActionRepository implements IBrowserActionRepository {
  async create(data: InsertBrowserAction): Promise<BrowserAction> {
    const [action] = await db.insert(browserActions).values(data).returning();
    return action;
  }

  async getByTaskId(taskId: string, limit: number = 100): Promise<BrowserAction[]> {
    return await db
      .select()
      .from(browserActions)
      .where(eq(browserActions.taskId, taskId))
      .orderBy(desc(browserActions.createdAt))
      .limit(limit);
  }

  async getById(id: string): Promise<BrowserAction | null> {
    const [action] = await db
      .select()
      .from(browserActions)
      .where(eq(browserActions.id, id))
      .limit(1);
    return action || null;
  }

  async updateStatus(
    id: string,
    status: string,
    result?: any,
    error?: string
  ): Promise<BrowserAction | null> {
    const updateData: any = { status };
    
    if (status === "executing") {
      updateData.executedAt = new Date();
    } else if (status === "completed" || status === "failed") {
      updateData.completedAt = new Date();
    }
    
    if (result !== undefined) {
      updateData.result = result;
    }
    
    if (error) {
      updateData.error = error;
    }

    const [updated] = await db
      .update(browserActions)
      .set(updateData)
      .where(eq(browserActions.id, id))
      .returning();
    
    return updated || null;
  }
}
