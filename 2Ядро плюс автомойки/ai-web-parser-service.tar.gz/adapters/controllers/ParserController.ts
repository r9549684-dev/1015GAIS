import type { Request, Response } from "express";
import { CreateParsingTaskUseCase } from "../../application/use-cases/CreateParsingTaskUseCase";
import { GetTaskStatusUseCase } from "../../application/use-cases/GetTaskStatusUseCase";
import { ParseDocumentationUseCase } from "../../application/use-cases/ParseDocumentationUseCase";
import { ParsingTaskRepository } from "../repositories/ParsingTaskRepository";
import { ParsingResultRepository } from "../repositories/ParsingResultRepository";
import { KnowledgeEntryRepository } from "../repositories/KnowledgeEntryRepository";
import { ParserGateway } from "../gateways/ParserGateway";
import { ParsingLogger } from "../gateways/ParsingLogger";
import { insertParsingTaskSchema } from "../../shared/schema";
import { fromZodError } from "zod-validation-error";

export class ParserController {
  private createTaskUseCase: CreateParsingTaskUseCase;
  private getTaskStatusUseCase: GetTaskStatusUseCase;
  private parseDocumentationUseCase: ParseDocumentationUseCase;

  constructor() {
    const taskRepository = new ParsingTaskRepository();
    const resultRepository = new ParsingResultRepository();
    const knowledgeRepository = new KnowledgeEntryRepository();
    const parserGateway = new ParserGateway();
    const logger = new ParsingLogger();

    this.createTaskUseCase = new CreateParsingTaskUseCase(taskRepository, logger);
    this.getTaskStatusUseCase = new GetTaskStatusUseCase(taskRepository);
    this.parseDocumentationUseCase = new ParseDocumentationUseCase(
      taskRepository,
      resultRepository,
      knowledgeRepository,
      parserGateway,
      logger
    );
  }

  createTask = async (req: Request, res: Response): Promise<void> => {
    try {
      const validation = insertParsingTaskSchema.safeParse(req.body);

      if (!validation.success) {
        const validationError = fromZodError(validation.error);
        res.status(400).json({
          error: "Validation failed",
          details: validationError.message,
        });
        return;
      }

      const result = await this.createTaskUseCase.execute(validation.data as any);

      res.status(201).json(result);
    } catch (error: any) {
      console.error("Error creating parsing task:", error);
      res.status(500).json({ error: error.message });
    }
  };

  getTaskStatus = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const result = await this.getTaskStatusUseCase.execute(taskId);
      res.json(result);
    } catch (error: any) {
      console.error("Error getting task status:", error);
      res.status(404).json({ error: error.message });
    }
  };

  parseTask = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const result = await this.parseDocumentationUseCase.execute(taskId);
      res.json(result);
    } catch (error: any) {
      console.error("Error parsing task:", error);
      res.status(500).json({ error: error.message });
    }
  };

  healthCheck = async (req: Request, res: Response): Promise<void> => {
    try {
      const gateway = new ParserGateway();
      const health = await gateway.healthCheck();
      res.json({
        service: "parser-service",
        status: "healthy",
        timestamp: new Date().toISOString(),
        parserGateway: health,
      });
    } catch (error: any) {
      res.status(500).json({
        service: "parser-service",
        status: "unhealthy",
        error: error.message,
      });
    }
  };
}
