import type { Request, Response } from "express";
import type { ExecuteAIParsingUseCase } from "../../application/use-cases/ExecuteAIParsingUseCase";
import type { GenerateHumanMouseMovementUseCase } from "../../application/use-cases/GenerateHumanMouseMovementUseCase";
import type { GetHMMStateUseCase } from "../../application/use-cases/GetHMMStateUseCase";
import type { GetBrowserActionsUseCase } from "../../application/use-cases/GetBrowserActionsUseCase";
import type { GetMouseMovementsUseCase } from "../../application/use-cases/GetMouseMovementsUseCase";
import type { GetAIDecisionsUseCase } from "../../application/use-cases/GetAIDecisionsUseCase";
import type { IMistralGateway } from "../gateways/IMistralGateway";
import type { IPlaywrightGateway } from "../gateways/IPlaywrightGateway";

export class AIParserController {
  constructor(
    private executeAIParsingUseCase: ExecuteAIParsingUseCase,
    private generateMouseMovementUseCase: GenerateHumanMouseMovementUseCase,
    private getHMMStateUseCase: GetHMMStateUseCase,
    private getBrowserActionsUseCase: GetBrowserActionsUseCase,
    private getMouseMovementsUseCase: GetMouseMovementsUseCase,
    private getAIDecisionsUseCase: GetAIDecisionsUseCase,
    private mistralGateway: IMistralGateway,
    private playwrightGateway: IPlaywrightGateway
  ) {}

  executeAIParsing = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const { url, sourceType, enableHMM, maxPages } = req.body;

      if (!url || !sourceType) {
        res.status(400).json({
          error: "Missing required fields",
          details: "url and sourceType are required",
        });
        return;
      }

      const result = await this.executeAIParsingUseCase.execute({
        taskId,
        url,
        sourceType,
        enableHMM: enableHMM ?? true,
        maxPages: maxPages ?? 5,
      });

      res.json(result);
    } catch (error: any) {
      console.error("Error executing AI parsing:", error);
      res.status(500).json({ error: error.message });
    }
  };

  generateMouseMovement = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId, actionType, targetElement, fromX, fromY, toX, toY } = req.body;

      if (fromX === undefined || fromY === undefined || toX === undefined || toY === undefined) {
        res.status(400).json({
          error: "Missing required coordinates",
          details: "fromX, fromY, toX, toY, actionType, and targetElement are required",
        });
        return;
      }

      const movement = await this.generateMouseMovementUseCase.execute({
        taskId: taskId || "test-task",
        actionType: actionType || "click",
        targetElement: targetElement || "button",
        fromX,
        fromY,
        toX,
        toY,
      });

      res.json(movement);
    } catch (error: any) {
      console.error("Error generating mouse movement:", error);
      res.status(500).json({ error: error.message });
    }
  };

  getHMMState = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const state = await this.getHMMStateUseCase.execute(taskId);

      if (!state) {
        res.status(404).json({ error: "HMM state not found" });
        return;
      }

      res.json(state);
    } catch (error: any) {
      console.error("Error getting HMM state:", error);
      res.status(500).json({ error: error.message });
    }
  };

  getBrowserActions = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const actions = await this.getBrowserActionsUseCase.execute(taskId, limit);

      res.json(actions);
    } catch (error: any) {
      console.error("Error getting browser actions:", error);
      res.status(500).json({ error: error.message });
    }
  };

  getMouseMovements = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const movements = await this.getMouseMovementsUseCase.execute(taskId, limit);

      res.json(movements);
    } catch (error: any) {
      console.error("Error getting mouse movements:", error);
      res.status(500).json({ error: error.message });
    }
  };

  getAIDecisions = async (req: Request, res: Response): Promise<void> => {
    try {
      const { taskId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const decisions = await this.getAIDecisionsUseCase.execute(taskId, limit);

      res.json(decisions);
    } catch (error: any) {
      console.error("Error getting AI decisions:", error);
      res.status(500).json({ error: error.message });
    }
  };

  healthCheck = async (req: Request, res: Response): Promise<void> => {
    try {
      const mistralHealth = await this.mistralGateway.healthCheck();
      const playwrightHealth = await this.playwrightGateway.healthCheck();

      res.json({
        service: "ai-parser-service",
        status: "healthy",
        timestamp: new Date().toISOString(),
        dependencies: {
          mistral: mistralHealth,
          playwright: playwrightHealth,
        },
      });
    } catch (error: any) {
      res.status(500).json({
        service: "ai-parser-service",
        status: "unhealthy",
        error: error.message,
      });
    }
  };
}
