# Parser Service - Standalone with Clean Architecture

## Обзор

Parser Service - это независимый микросервис для парсинга веб-страниц, документации и извлечения знаний, построенный на принципах Clean Architecture.

**Основные возможности:**
- ✅ Парсинг веб-страниц и документации
- ✅ Извлечение структурированных данных (заголовки, код, таблицы)
- ✅ Накопление базы знаний
- ✅ Интеграция с внешним Parser API (89.208.107.67:8001)
- ✅ Fallback на встроенный парсер
- ✅ REST API для интеграции
- ✅ Clean Architecture (4 слоя)

---

## Архитектура

```
parser-service/
├── domain/                     # Domain Layer
│   └── entities/
│       ├── ParsingTask.ts      # Задача парсинга
│       ├── ParsingResult.ts    # Результат парсинга
│       └── KnowledgeEntry.ts   # Запись знаний
│
├── application/                # Application Layer
│   └── use-cases/
│       ├── CreateParsingTaskUseCase.ts
│       ├── GetTaskStatusUseCase.ts
│       └── ParseDocumentationUseCase.ts
│
├── adapters/                   # Adapters Layer
│   ├── repositories/
│   │   ├── IParsingTaskRepository.ts
│   │   ├── ParsingTaskRepository.ts
│   │   ├── IParsingResultRepository.ts
│   │   ├── ParsingResultRepository.ts
│   │   ├── IKnowledgeEntryRepository.ts
│   │   └── KnowledgeEntryRepository.ts
│   ├── gateways/
│   │   ├── IParserGateway.ts
│   │   ├── ParserGateway.ts    # Интеграция с внешним API
│   │   ├── IParsingLogger.ts
│   │   └── ParsingLogger.ts
│   └── controllers/
│       └── ParserController.ts
│
├── infrastructure/             # Infrastructure Layer
│   ├── routes.ts
│   ├── storage.ts
│   └── server.ts (optional)
│
└── shared/
    └── schema.ts               # Database schema (5 таблиц)
```

---

## Database Schema

### 5 таблиц с Clean Architecture

```sql
-- Задачи на парсинг
CREATE TABLE parsing_tasks (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  url TEXT NOT NULL,
  source_type TEXT NOT NULL,  -- 'documentation', 'website', 'api_spec', 'code_repository'
  status TEXT NOT NULL DEFAULT 'pending',  -- pending, processing, completed, failed
  priority TEXT NOT NULL DEFAULT 'normal', -- low, normal, high, urgent
  options JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  started_at TIMESTAMP,
  completed_at TIMESTAMP
);

-- Результаты парсинга
CREATE TABLE parsing_results (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id VARCHAR NOT NULL REFERENCES parsing_tasks(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  content_type TEXT NOT NULL,  -- 'html', 'markdown', 'json', 'plain_text'
  metadata JSONB,
  extracted_data JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- База знаний
CREATE TABLE knowledge_entries (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id VARCHAR REFERENCES parsing_tasks(id) ON DELETE SET NULL,
  source_type TEXT NOT NULL,
  content TEXT NOT NULL,
  summary TEXT,
  tags TEXT[],
  category TEXT,  -- 'tutorial', 'api_reference', 'best_practice', 'example'
  relevance_score TEXT DEFAULT '0',
  metadata JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Логи парсинга
CREATE TABLE parsing_logs (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id VARCHAR REFERENCES parsing_tasks(id) ON DELETE CASCADE,
  level TEXT NOT NULL,  -- 'info', 'warning', 'error', 'debug'
  message TEXT NOT NULL,
  details JSONB,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Учетные данные для интеграций
CREATE TABLE integration_credentials (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name TEXT NOT NULL UNIQUE,  -- 'aigentforge', 'leadgen_pro'
  api_key TEXT,
  webhook_url TEXT,
  config JSONB,
  is_active TEXT NOT NULL DEFAULT 'true',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);
```

---

## REST API

### Base URL

```
http://localhost:5000/api/parser
```

### Endpoints

#### 1. Health Check

```http
GET /api/parser/health
```

**Response:**
```json
{
  "service": "parser-service",
  "status": "healthy",
  "timestamp": "2025-10-08T17:00:00.000Z",
  "parserGateway": {
    "status": "healthy",
    "message": "External parser available"
  }
}
```

#### 2. Create Parsing Task

```http
POST /api/parser/tasks
Content-Type: application/json

{
  "url": "https://docs.example.com",
  "sourceType": "documentation",
  "priority": "normal",
  "options": {
    "depth": 3,
    "maxPages": 100,
    "selectors": [".main-content"],
    "followLinks": true,
    "extractStructuredData": true
  }
}
```

**Response:**
```json
{
  "taskId": "550e8400-e29b-41d4-a716-446655440000",
  "status": "pending",
  "message": "Parsing task created successfully"
}
```

#### 3. Get Task Status

```http
GET /api/parser/tasks/:taskId
```

**Response:**
```json
{
  "taskId": "550e8400-e29b-41d4-a716-446655440000",
  "status": "completed",
  "url": "https://docs.example.com",
  "sourceType": "documentation",
  "createdAt": "2025-10-08T17:00:00.000Z",
  "startedAt": "2025-10-08T17:00:01.000Z",
  "completedAt": "2025-10-08T17:00:15.000Z",
  "duration": 14000
}
```

#### 4. Parse Task (Execute)

```http
POST /api/parser/tasks/:taskId/parse
```

**Response:**
```json
{
  "taskId": "550e8400-e29b-41d4-a716-446655440000",
  "resultId": "660e8400-e29b-41d4-a716-446655440001",
  "knowledgeEntries": 15,
  "status": "completed"
}
```

---

## Интеграция с AiGentForge

### Шаг 1: Добавить роуты в основной сервер

```typescript
// server/routes.ts
import { parserRouter } from "../parser-service/infrastructure/routes";

// Add parser routes
app.use("/api/parser", parserRouter);
```

### Шаг 2: Использовать в AiGentForge

```typescript
// server/services/parser-integration.ts
import axios from "axios";

export class AiGentForgeParserIntegration {
  private baseUrl = "http://localhost:5000/api/parser";

  async parseDocumentation(url: string): Promise<string> {
    // 1. Create task
    const createResponse = await axios.post(`${this.baseUrl}/tasks`, {
      url,
      sourceType: "documentation",
      priority: "high",
    });

    const taskId = createResponse.data.taskId;

    // 2. Execute parsing
    await axios.post(`${this.baseUrl}/tasks/${taskId}/parse`);

    // 3. Wait for completion
    let status = "processing";
    while (status === "processing" || status === "pending") {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      const statusResponse = await axios.get(`${this.baseUrl}/tasks/${taskId}`);
      status = statusResponse.data.status;
    }

    if (status === "failed") {
      throw new Error("Parsing failed");
    }

    return taskId;
  }
}
```

---

## Интеграция с LeadGen Pro

### Использовать для парсинга бизнесов

```typescript
// server/services/leadgen-parser-integration.ts
import axios from "axios";

export class LeadGenParserIntegration {
  private baseUrl = "http://localhost:5000/api/parser";

  async parseBusinessDirectory(url: string, city: string): Promise<any> {
    // Create parsing task
    const { data } = await axios.post(`${this.baseUrl}/tasks`, {
      url,
      sourceType: "website",
      priority: "urgent",
      options: {
        depth: 2,
        maxPages: 50,
        selectors: [".business-card", ".listing"],
      },
    });

    // Execute parsing
    await axios.post(`${this.baseUrl}/tasks/${data.taskId}/parse`);

    // Poll for results
    const result = await this.pollForResults(data.taskId);
    return result;
  }

  private async pollForResults(taskId: string): Promise<any> {
    // Implementation
  }
}
```

---

## Интеграция с Любой Другой Системой

### Пример: Express приложение

```typescript
import express from "express";
import axios from "axios";

const app = express();

app.post("/my-app/parse", async (req, res) => {
  const { url } = req.body;

  try {
    // 1. Create task
    const createRes = await axios.post("http://parser-service:5000/api/parser/tasks", {
      url,
      sourceType: "documentation",
    });

    const taskId = createRes.data.taskId;

    // 2. Execute parsing
    await axios.post(`http://parser-service:5000/api/parser/tasks/${taskId}/parse`);

    // 3. Get results
    const statusRes = await axios.get(
      `http://parser-service:5000/api/parser/tasks/${taskId}`
    );

    res.json(statusRes.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

## Преимущества Clean Architecture

### 1. Независимость от Фреймворков
- Легко менять Express на Fastify или Koa
- Переиспользовать Use Cases в любом окружении

### 2. Тестируемость
```typescript
// test/CreateParsingTaskUseCase.test.ts
import { CreateParsingTaskUseCase } from "../application/use-cases/CreateParsingTaskUseCase";

const mockRepository = {
  create: jest.fn(),
};
const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
};

const useCase = new CreateParsingTaskUseCase(mockRepository, mockLogger);
const result = await useCase.execute({ url: "https://example.com", sourceType: "documentation" });

expect(mockRepository.create).toHaveBeenCalled();
```

### 3. Легкая Интеграция
- REST API для синхронной интеграции
- Можно добавить WebSocket для real-time
- Можно добавить Message Queue (RabbitMQ, Kafka)

### 4. Масштабируемость
- Легко добавить новые Use Cases
- Легко заменить Gateway (другой парсер API)
- Легко заменить Repository (другая БД)

---

## Конфигурация

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/db

# External Parser (optional)
PARSER_API_URL=http://89.208.107.67:8001

# Server
PORT=5000
```

---

## Установка и Запуск

### Как Standalone Service

```bash
# 1. Install dependencies
npm install

# 2. Setup .env
echo "DATABASE_URL=postgresql://..." > .env

# 3. Push schema to DB
npm run db:push

# 4. Start service
npm run dev
```

### Как Часть Основного Приложения

```bash
# Уже работает в текущем проекте!
# Просто добавьте роуты в server/routes.ts
```

---

## Примеры Использования

### 1. Парсинг TypeScript документации

```bash
curl -X POST http://localhost:5000/api/parser/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://www.typescriptlang.org/docs/",
    "sourceType": "documentation",
    "priority": "high"
  }'

# Response: { "taskId": "..." }

curl -X POST http://localhost:5000/api/parser/tasks/{taskId}/parse

curl http://localhost:5000/api/parser/tasks/{taskId}
# Response: { "status": "completed", "duration": 15000, ... }
```

### 2. Парсинг с Custom Options

```bash
curl -X POST http://localhost:5000/api/parser/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://api.example.com/docs",
    "sourceType": "api_spec",
    "options": {
      "depth": 5,
      "maxPages": 200,
      "selectors": [".endpoint", ".parameter"],
      "headers": {
        "Authorization": "Bearer token"
      }
    }
  }'
```

---

## Roadmap

- [ ] WebSocket для real-time прогресса
- [ ] Message Queue интеграция (RabbitMQ)
- [ ] Crawler для рекурсивного парсинга
- [ ] AI-powered content extraction (через LLM)
- [ ] Screenshot capture для визуального анализа
- [ ] PDF парсинг
- [ ] API spec парсинг (OpenAPI, Swagger)

---

## Версия

**1.0.0** - 08.10.2025

**Статус:** Production-Ready ✅

**Clean Architecture:** Полностью реализована  
**Интеграция:** REST API готов  
**Тестирование:** Готов к юнит и интеграционным тестам
