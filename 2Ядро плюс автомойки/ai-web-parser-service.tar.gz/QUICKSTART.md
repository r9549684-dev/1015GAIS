# AI Web Parser Service - Quick Start

## 🚀 Быстрый старт за 5 минут

### Шаг 1: Распаковка архива
```bash
unzip ai-web-parser-service.zip
cd ai-web-parser-service
```

### Шаг 2: Установка зависимостей
```bash
npm install
npx playwright install chromium
```

### Шаг 3: Настройка БД
```bash
# Скопировать пример конфигурации
cp .env.example .env

# Отредактировать .env - указать данные PostgreSQL
nano .env
```

### Шаг 4: Инициализация базы данных
```bash
npm run db:push
```

### Шаг 5: Запуск
```bash
# Development режим
npm run dev

# Production режим
npm run build
npm start
```

### Шаг 6: Проверка
```bash
# Health check
curl http://localhost:5000/api/parser-ai/ai/health

# Ожидаемый ответ:
{
  "service": "ai-parser-service",
  "status": "healthy",
  ...
}
```

## 📚 Документация

- **Полное руководство**: `DEPLOYMENT_GUIDE_RU.md`
- **API документация**: `README.md`
- **Примеры интеграции**: `INTEGRATION_GUIDE.md`

## 🔧 Конфигурация

### Минимальная (без Mistral AI)
Система работает с fallback алгоритмом без внешнего AI.

### Полная (с Mistral AI)
Укажите в `.env`:
```env
MISTRAL_API_URL=http://your-mistral-server:8000
```

## 📦 Структура архива

```
ai-web-parser-service/
├── domain/              # Entities (чистый бизнес-логика)
├── application/         # Use Cases + Ports (интерфейсы)
├── adapters/           # Implementations (repositories, gateways, controllers)
├── infrastructure/     # DI Container, Routes, Services
├── shared/             # Schema (Drizzle ORM)
├── DEPLOYMENT_GUIDE_RU.md  # 📖 Полное руководство
├── QUICKSTART.md           # ⚡ Быстрый старт
├── package.json
├── .env.example
└── tsconfig.json
```

## 🆘 Помощь

**Mistral недоступен?** - Система автоматически использует fallback  
**Playwright ошибки?** - `npx playwright install chromium --force`  
**Таблицы не созданы?** - `npm run db:push --force`

## 🎯 Первый тест

```bash
# Генерация человекоподобного движения мыши
curl -X POST http://localhost:5000/api/parser-ai/mouse/generate \
  -H "Content-Type: application/json" \
  -d '{
    "taskId": "test-001",
    "actionType": "click",
    "targetElement": "button",
    "fromX": 100,
    "fromY": 100,
    "toX": 500,
    "toY": 300
  }'
```

**Успех!** Теперь вы готовы к интеграции! 🎉
