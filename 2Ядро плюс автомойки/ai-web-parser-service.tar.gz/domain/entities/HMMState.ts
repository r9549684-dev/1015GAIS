/**
 * Hidden Markov Model State Entity
 * Управляет состоянием парсинга через вероятностную модель
 */

export type HMMStateType = "initial" | "exploring" | "extracting" | "refining" | "completed" | "failed";

export interface TransitionProbability {
  from: HMMStateType;
  to: HMMStateType;
  probability: number;
}

export interface Observation {
  timestamp: Date;
  action: string;
  success: boolean;
  metrics?: {
    pagesProcessed?: number;
    dataExtracted?: number;
    errorsCount?: number;
  };
}

export class HMMStateEntity {
  constructor(
    public readonly id: string,
    public readonly taskId: string,
    public currentState: HMMStateType,
    public previousState: HMMStateType | null,
    public transitionProbabilities: TransitionProbability[],
    public observations: Observation[],
    public readonly createdAt: Date,
    public updatedAt: Date
  ) {}

  static create(taskId: string): Omit<HMMStateEntity, "id" | "createdAt" | "updatedAt"> {
    return {
      taskId,
      currentState: "initial",
      previousState: null,
      transitionProbabilities: HMMStateEntity.getInitialProbabilities(),
      observations: [],
    };
  }

  static getInitialProbabilities(): TransitionProbability[] {
    return [
      { from: "initial", to: "exploring", probability: 0.9 },
      { from: "initial", to: "failed", probability: 0.1 },
      { from: "exploring", to: "extracting", probability: 0.7 },
      { from: "exploring", to: "refining", probability: 0.2 },
      { from: "exploring", to: "failed", probability: 0.1 },
      { from: "extracting", to: "refining", probability: 0.3 },
      { from: "extracting", to: "completed", probability: 0.6 },
      { from: "extracting", to: "failed", probability: 0.1 },
      { from: "refining", to: "extracting", probability: 0.5 },
      { from: "refining", to: "completed", probability: 0.4 },
      { from: "refining", to: "failed", probability: 0.1 },
    ];
  }

  transition(newState: HMMStateType): void {
    this.previousState = this.currentState;
    this.currentState = newState;
    this.updatedAt = new Date();
  }

  addObservation(observation: Observation): void {
    this.observations.push(observation);
    this.updateProbabilities(observation);
    this.updatedAt = new Date();
  }

  private updateProbabilities(observation: Observation): void {
    if (!this.previousState) return;

    const transition = this.transitionProbabilities.find(
      (t) => t.from === this.previousState && t.to === this.currentState
    );

    if (transition) {
      // Bayes update: increase probability if success, decrease if failure
      const learningRate = 0.1;
      const adjustment = observation.success ? learningRate : -learningRate;
      transition.probability = Math.max(0.05, Math.min(0.95, transition.probability + adjustment));

      // Normalize probabilities for this state
      this.normalizeProbabilitiesFrom(this.previousState);
    }
  }

  private normalizeProbabilitiesFrom(state: HMMStateType): void {
    const transitions = this.transitionProbabilities.filter((t) => t.from === state);
    const sum = transitions.reduce((acc, t) => acc + t.probability, 0);

    if (sum > 0) {
      transitions.forEach((t) => {
        t.probability = t.probability / sum;
      });
    }
  }

  getNextStateWithProbability(): { state: HMMStateType; probability: number } | null {
    const possibleTransitions = this.transitionProbabilities.filter(
      (t) => t.from === this.currentState
    );

    if (possibleTransitions.length === 0) return null;

    // Select state with highest probability
    return possibleTransitions.reduce((max, t) =>
      t.probability > max.probability ? { state: t.to, probability: t.probability } : max
    , { state: possibleTransitions[0].to, probability: possibleTransitions[0].probability });
  }

  shouldTransitionTo(targetState: HMMStateType): boolean {
    const transition = this.transitionProbabilities.find(
      (t) => t.from === this.currentState && t.to === targetState
    );

    return transition ? transition.probability > 0.5 : false;
  }

  getSuccessRate(): number {
    if (this.observations.length === 0) return 0;
    const successCount = this.observations.filter((o) => o.success).length;
    return successCount / this.observations.length;
  }
}
