export type KnowledgeCategory = "tutorial" | "api_reference" | "best_practice" | "example" | "general";

export class KnowledgeEntryEntity {
  constructor(
    public readonly id: string,
    public readonly taskId: string | null,
    public readonly sourceType: string,
    public readonly content: string,
    public summary: string | null,
    public tags: string[],
    public category: KnowledgeCategory | null,
    public relevanceScore: number,
    public readonly metadata: Record<string, any>,
    public readonly createdAt: Date,
    public updatedAt: Date
  ) {}

  static create(
    sourceType: string,
    content: string,
    category: KnowledgeCategory | null = null,
    tags: string[] = [],
    taskId: string | null = null,
    metadata: Record<string, any> = {}
  ): {
    taskId: string | null;
    sourceType: string;
    content: string;
    category: KnowledgeCategory | null;
    tags: string[];
    metadata: Record<string, any>;
  } {
    return {
      taskId,
      sourceType,
      content,
      category,
      tags,
      metadata,
    };
  }

  validate(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!this.content || this.content.trim().length === 0) {
      errors.push("Content cannot be empty");
    }

    if (this.content.length > 50000) { // 50KB limit for knowledge entry
      errors.push("Content exceeds maximum size (50KB)");
    }

    if (!this.sourceType || this.sourceType.trim().length === 0) {
      errors.push("Source type is required");
    }

    if (this.relevanceScore < 0 || this.relevanceScore > 100) {
      errors.push("Relevance score must be between 0 and 100");
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  updateSummary(summary: string): void {
    this.summary = summary;
    this.updatedAt = new Date();
  }

  addTags(newTags: string[]): void {
    const uniqueTags = new Set([...this.tags, ...newTags]);
    this.tags = Array.from(uniqueTags);
    this.updatedAt = new Date();
  }

  removeTags(tagsToRemove: string[]): void {
    this.tags = this.tags.filter(tag => !tagsToRemove.includes(tag));
    this.updatedAt = new Date();
  }

  setRelevanceScore(score: number): void {
    if (score < 0 || score > 100) {
      throw new Error("Relevance score must be between 0 and 100");
    }
    this.relevanceScore = score;
    this.updatedAt = new Date();
  }

  setCategory(category: KnowledgeCategory): void {
    this.category = category;
    this.updatedAt = new Date();
  }

  isHighlyRelevant(): boolean {
    return this.relevanceScore >= 70;
  }

  hasTag(tag: string): boolean {
    return this.tags.includes(tag);
  }

  getExcerpt(maxLength: number = 150): string {
    if (this.content.length <= maxLength) {
      return this.content;
    }
    return this.content.substring(0, maxLength) + "...";
  }
}
