export type ContentType = "html" | "markdown" | "json" | "plain_text";

export interface ExtractedMetadata {
  title?: string;
  description?: string;
  author?: string;
  publishedDate?: string;
  modifiedDate?: string;
  language?: string;
  keywords?: string[];
  links?: string[];
  images?: string[];
}

export interface ExtractedData {
  headings?: { level: number; text: string }[];
  codeBlocks?: { language: string; code: string }[];
  tables?: any[][];
  lists?: string[][];
  structuredData?: any; // JSON-LD, microdata, etc.
}

export class ParsingResultEntity {
  constructor(
    public readonly id: string,
    public readonly taskId: string,
    public readonly content: string,
    public readonly contentType: ContentType,
    public readonly metadata: ExtractedMetadata,
    public readonly extractedData: ExtractedData,
    public readonly createdAt: Date
  ) {}

  static create(
    taskId: string,
    content: string,
    contentType: ContentType,
    metadata: ExtractedMetadata = {},
    extractedData: ExtractedData = {}
  ): Omit<ParsingResultEntity, "id" | "createdAt"> {
    return {
      taskId,
      content,
      contentType,
      metadata,
      extractedData,
    };
  }

  validate(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!this.taskId) {
      errors.push("Task ID is required");
    }

    if (!this.content || this.content.trim().length === 0) {
      errors.push("Content cannot be empty");
    }

    if (this.content.length > 10000000) { // 10MB limit
      errors.push("Content exceeds maximum size (10MB)");
    }

    const validContentTypes: ContentType[] = ["html", "markdown", "json", "plain_text"];
    if (!validContentTypes.includes(this.contentType)) {
      errors.push(`Invalid content type. Must be one of: ${validContentTypes.join(", ")}`);
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  getContentSize(): number {
    return Buffer.byteLength(this.content, "utf8");
  }

  hasMetadata(): boolean {
    return Object.keys(this.metadata).length > 0;
  }

  hasExtractedData(): boolean {
    return Object.keys(this.extractedData).length > 0;
  }

  getExcerpt(maxLength: number = 200): string {
    if (this.content.length <= maxLength) {
      return this.content;
    }
    return this.content.substring(0, maxLength) + "...";
  }

  countLinks(): number {
    return this.metadata.links?.length || 0;
  }

  countCodeBlocks(): number {
    return this.extractedData.codeBlocks?.length || 0;
  }
}
