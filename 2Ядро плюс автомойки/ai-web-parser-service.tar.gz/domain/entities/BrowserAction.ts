/**
 * Browser Action Entity
 * Представляет действие в браузере (клик, скролл, ввод текста)
 */

export type ActionType = 
  | "navigate"
  | "click"
  | "type"
  | "scroll"
  | "wait"
  | "hover"
  | "screenshot"
  | "extract_html";

export interface ActionContext {
  selector?: string;
  text?: string;
  url?: string;
  scrollAmount?: number;
  waitTime?: number;
  mouseMovementId?: string;
}

export class BrowserActionEntity {
  constructor(
    public readonly id: string,
    public readonly taskId: string,
    public readonly actionType: ActionType,
    public readonly context: ActionContext,
    public readonly executeWithHMM: boolean, // Использовать HumanMouse Module
    public status: "pending" | "executing" | "completed" | "failed",
    public result: any,
    public error: string | null,
    public readonly createdAt: Date,
    public executedAt: Date | null,
    public completedAt: Date | null
  ) {}

  static create(
    taskId: string,
    actionType: ActionType,
    context: ActionContext,
    executeWithHMM: boolean = true
  ): Omit<BrowserActionEntity, "id" | "createdAt" | "executedAt" | "completedAt" | "status" | "result" | "error"> {
    return {
      taskId,
      actionType,
      context,
      executeWithHMM,
    };
  }

  validate(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    switch (this.actionType) {
      case "navigate":
        if (!this.context.url) {
          errors.push("Navigate action requires URL");
        }
        break;
      case "click":
      case "hover":
        if (!this.context.selector) {
          errors.push(`${this.actionType} action requires selector`);
        }
        break;
      case "type":
        if (!this.context.selector || !this.context.text) {
          errors.push("Type action requires selector and text");
        }
        break;
      case "scroll":
        if (this.context.scrollAmount === undefined) {
          errors.push("Scroll action requires scrollAmount");
        }
        break;
      case "wait":
        if (!this.context.waitTime || this.context.waitTime <= 0) {
          errors.push("Wait action requires positive waitTime");
        }
        break;
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  start(): void {
    if (this.status !== "pending") {
      throw new Error(`Cannot start action with status: ${this.status}`);
    }
    this.status = "executing";
    this.executedAt = new Date();
  }

  complete(result: any): void {
    if (this.status !== "executing") {
      throw new Error(`Cannot complete action with status: ${this.status}`);
    }
    this.status = "completed";
    this.result = result;
    this.completedAt = new Date();
  }

  fail(error: string): void {
    if (this.status === "completed") {
      throw new Error("Cannot fail an already completed action");
    }
    this.status = "failed";
    this.error = error;
    this.completedAt = new Date();
  }

  getDuration(): number | null {
    if (!this.executedAt || !this.completedAt) return null;
    return this.completedAt.getTime() - this.executedAt.getTime();
  }

  requiresMouseMovement(): boolean {
    return this.executeWithHMM && (this.actionType === "click" || this.actionType === "hover");
  }
}
