export type ParsingStatus = "pending" | "processing" | "completed" | "failed";
export type ParsingPriority = "low" | "normal" | "high" | "urgent";
export type SourceType = "documentation" | "website" | "api_spec" | "code_repository";

export interface ParsingOptions {
  depth?: number; // Max crawl depth
  maxPages?: number; // Max pages to parse
  selectors?: string[]; // CSS selectors for content extraction
  headers?: Record<string, string>; // Custom HTTP headers
  timeout?: number; // Request timeout in ms
  followLinks?: boolean; // Follow internal links
  extractStructuredData?: boolean; // Extract JSON-LD, microdata, etc.
}

export class ParsingTaskEntity {
  constructor(
    public readonly id: string,
    public readonly url: string,
    public readonly sourceType: SourceType,
    public status: ParsingStatus,
    public readonly priority: ParsingPriority,
    public readonly options: ParsingOptions,
    public readonly createdAt: Date,
    public startedAt: Date | null,
    public completedAt: Date | null
  ) {}

  static create(
    url: string,
    sourceType: SourceType,
    priority: ParsingPriority = "normal",
    options: ParsingOptions = {}
  ): Omit<ParsingTaskEntity, "id" | "createdAt" | "startedAt" | "completedAt"> {
    return {
      url,
      sourceType,
      status: "pending",
      priority,
      options,
    };
  }

  validate(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Validate URL
    try {
      new URL(this.url);
    } catch {
      errors.push("Invalid URL format");
    }

    // Validate source type
    const validSourceTypes: SourceType[] = ["documentation", "website", "api_spec", "code_repository"];
    if (!validSourceTypes.includes(this.sourceType)) {
      errors.push(`Invalid source type. Must be one of: ${validSourceTypes.join(", ")}`);
    }

    // Validate priority
    const validPriorities: ParsingPriority[] = ["low", "normal", "high", "urgent"];
    if (!validPriorities.includes(this.priority)) {
      errors.push(`Invalid priority. Must be one of: ${validPriorities.join(", ")}`);
    }

    // Validate options
    if (this.options.depth !== undefined && (this.options.depth < 1 || this.options.depth > 10)) {
      errors.push("Depth must be between 1 and 10");
    }

    if (this.options.maxPages !== undefined && (this.options.maxPages < 1 || this.options.maxPages > 1000)) {
      errors.push("Max pages must be between 1 and 1000");
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  start(): void {
    if (this.status !== "pending") {
      throw new Error(`Cannot start task with status: ${this.status}`);
    }
    this.status = "processing";
    this.startedAt = new Date();
  }

  complete(): void {
    if (this.status !== "processing") {
      throw new Error(`Cannot complete task with status: ${this.status}`);
    }
    this.status = "completed";
    this.completedAt = new Date();
  }

  fail(): void {
    if (this.status === "completed") {
      throw new Error("Cannot fail an already completed task");
    }
    this.status = "failed";
    this.completedAt = new Date();
  }

  isPending(): boolean {
    return this.status === "pending";
  }

  isProcessing(): boolean {
    return this.status === "processing";
  }

  isCompleted(): boolean {
    return this.status === "completed";
  }

  isFailed(): boolean {
    return this.status === "failed";
  }

  isFinished(): boolean {
    return this.isCompleted() || this.isFailed();
  }

  getDuration(): number | null {
    if (!this.startedAt || !this.completedAt) {
      return null;
    }
    return this.completedAt.getTime() - this.startedAt.getTime();
  }
}
