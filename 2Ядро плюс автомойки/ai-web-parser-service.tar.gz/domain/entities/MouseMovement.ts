/**
 * Mouse Movement Entity
 * Представляет человекоподобное движение мыши, сгенерированное через AI
 */

export interface BezierPoint {
  x: number;
  y: number;
}

export interface MouseMovementParams {
  jitter: number; // Дрожание курсора (0-10)
  speed: number; // Скорость движения (px/ms)
  curvature: number; // Кривизна траектории (0-1)
  pauseProbability: number; // Вероятность пауз (0-1)
  overshoot: number; // Промах за цель (0-20 px)
}

export class MouseMovementEntity {
  constructor(
    public readonly id: string,
    public readonly taskId: string,
    public readonly fromX: number,
    public readonly fromY: number,
    public readonly toX: number,
    public readonly toY: number,
    public readonly params: MouseMovementParams,
    public readonly bezierPoints: BezierPoint[],
    public readonly generatedBy: "ai" | "default",
    public readonly aiPrompt: string | null,
    public readonly createdAt: Date
  ) {}

  static create(
    taskId: string,
    fromX: number,
    fromY: number,
    toX: number,
    toY: number,
    params: MouseMovementParams,
    generatedBy: "ai" | "default" = "default",
    aiPrompt: string | null = null
  ): Omit<MouseMovementEntity, "id" | "createdAt" | "bezierPoints"> {
    return {
      taskId,
      fromX,
      fromY,
      toX,
      toY,
      params,
      generatedBy,
      aiPrompt,
    };
  }

  static getDefaultParams(): MouseMovementParams {
    return {
      jitter: 3,
      speed: 0.5,
      curvature: 0.3,
      pauseProbability: 0.15,
      overshoot: 5,
    };
  }

  validate(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (this.fromX < 0 || this.fromY < 0 || this.toX < 0 || this.toY < 0) {
      errors.push("Coordinates must be non-negative");
    }

    if (this.fromX > 10000 || this.fromY > 10000 || this.toX > 10000 || this.toY > 10000) {
      errors.push("Coordinates exceed maximum viewport size");
    }

    if (this.params.jitter < 0 || this.params.jitter > 10) {
      errors.push("Jitter must be between 0 and 10");
    }

    if (this.params.speed <= 0 || this.params.speed > 10) {
      errors.push("Speed must be between 0 and 10");
    }

    if (this.params.curvature < 0 || this.params.curvature > 1) {
      errors.push("Curvature must be between 0 and 1");
    }

    if (this.params.pauseProbability < 0 || this.params.pauseProbability > 1) {
      errors.push("Pause probability must be between 0 and 1");
    }

    if (this.params.overshoot < 0 || this.params.overshoot > 50) {
      errors.push("Overshoot must be between 0 and 50");
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  getDistance(): number {
    const dx = this.toX - this.fromX;
    const dy = this.toY - this.fromY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  getEstimatedDuration(): number {
    // Duration in milliseconds
    return this.getDistance() / this.params.speed;
  }

  isHumanLike(): boolean {
    // Human-like движения имеют:
    // - Умеренное дрожание (2-5)
    // - Среднюю скорость (0.3-0.8)
    // - Кривизну траектории (> 0.1)
    return (
      this.params.jitter >= 2 &&
      this.params.jitter <= 5 &&
      this.params.speed >= 0.3 &&
      this.params.speed <= 0.8 &&
      this.params.curvature > 0.1
    );
  }
}
