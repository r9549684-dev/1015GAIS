# AI Web Parser Service - Руководство по развертыванию и использованию

## 📋 Содержание
- [Описание системы](#описание-системы)
- [Архитектура](#архитектура)
- [Функции и возможности](#функции-и-возможности)
- [REST API](#rest-api)
- [Интеграция](#интеграция)
- [Управление через AI агента](#управление-через-ai-агента)
- [Установка и развертывание](#установка-и-развертывание)
- [Примеры использования](#примеры-использования)

---

## Описание системы

**AI Web Parser Service** — это автономная система интеллектуального веб-парсинга с HMM (Hidden Markov Model) для адаптивного обучения и модулем человекоподобного поведения (HumanMouse Module). Система построена на принципах Clean Architecture и полностью соответствует паттерну Dependency Inversion Principle.

### Ключевые особенности:
- ✅ **AI-управляемый парсинг**: Mistral-7B анализирует HTML, генерирует CSS-селекторы, принимает решения о следующих действиях
- ✅ **HMM адаптация**: Обучение на наблюдениях (успех/неудача), автоматическая корректировка стратегии
- ✅ **Человекоподобное поведение**: Движения мыши по Bezier кривым с jitter, паузами, промахами
- ✅ **Fallback механизм**: При недоступности AI используется эвристический алгоритм
- ✅ **Clean Architecture**: Полная изоляция слоев, легкое тестирование и замена компонентов
- ✅ **TypeScript**: Полная типизация для надежности кода

---

## Архитектура

### Clean Architecture Layers

```
┌─────────────────────────────────────────────┐
│           Domain Layer (Entities)            │
│  - HMMState                                   │
│  - MouseMovement                              │
│  - BrowserAction                              │
└─────────────────────────────────────────────┘
                    ↑
┌─────────────────────────────────────────────┐
│    Application Layer (Use Cases + Ports)     │
│  Use Cases:                                   │
│  - ExecuteAIParsingUseCase                    │
│  - GenerateHumanMouseMovementUseCase          │
│  - GetHMMStateUseCase                         │
│  - GetBrowserActionsUseCase                   │
│  - GetMouseMovementsUseCase                   │
│  - GetAIDecisionsUseCase                      │
│                                               │
│  Ports (Interfaces):                          │
│  - IHMMStateRepository                        │
│  - IMouseMovementRepository                   │
│  - IBrowserActionRepository                   │
│  - IAIDecisionLogRepository                   │
└─────────────────────────────────────────────┘
                    ↑
┌─────────────────────────────────────────────┐
│      Adapters Layer (Implementations)        │
│  Gateways:                                    │
│  - MistralService (IMistralGateway)          │
│  - PlaywrightService (IPlaywrightGateway)    │
│  - HMMEngineWithPersistence (IHMMGateway)    │
│                                               │
│  Repositories:                                │
│  - HMMStateRepository                         │
│  - MouseMovementRepository                    │
│  - BrowserActionRepository                    │
│  - AIDecisionLogRepository                    │
│                                               │
│  Controllers:                                 │
│  - AIParserController                         │
└─────────────────────────────────────────────┘
                    ↑
┌─────────────────────────────────────────────┐
│         Infrastructure Layer                 │
│  - DependencyInjection (DI Container)        │
│  - Routes (Express routing)                  │
│  - Storage (PostgreSQL)                      │
└─────────────────────────────────────────────┘
```

### Направление зависимостей
**Domain ← Application ← Adapters ← Infrastructure**

Все зависимости направлены внутрь. Application layer зависит только от Domain. Adapters реализуют интерфейсы из Application/Ports.

---

## Функции и возможности

### 1. AI-управляемый парсинг
- Анализ HTML-структуры через Mistral-7B
- Автоматическая генерация CSS-селекторов
- Принятие решений о следующих действиях (клик, скролл, ввод текста)
- Извлечение данных на основе AI-анализа

### 2. Hidden Markov Model (HMM)
- **Состояния**: initial → exploring → extracting → refining → completed/failed
- **Bayesian Update**: Обновление вероятностей переходов на основе наблюдений
- **Адаптивное обучение**: Автоматическая корректировка стратегии парсинга
- **Оценка эффективности**: Рекомендации по оптимальным переходам

### 3. Человекоподобное поведение (HumanMouse Module)
Генерация естественных движений мыши для обхода анти-бот систем:
- **Bezier кривые**: Плавные траектории движения
- **Jitter**: Случайные микро-отклонения
- **Pauses**: Естественные паузы во время движения
- **Overshoot**: Промахи с коррекцией
- **Variable Speed**: Изменяющаяся скорость движения
- **AI-генерация параметров**: Mistral генерирует уникальные параметры для каждого движения

### 4. Браузерная автоматизация (Playwright)
- Navigate, Click, Type, Scroll, Wait, Hover
- Скриншоты и извлечение HTML
- Полная эмуляция пользовательских действий
- Поддержка JavaScript-heavy сайтов

### 5. Fallback механизм
При недоступности AI-сервиса (Mistral-7B):
- Эвристические алгоритмы для генерации движений мыши
- Стандартные стратегии парсинга
- Продолжение работы без деградации функциональности

---

## REST API

**Базовый путь**: `/api/parser-ai`

### Endpoints

#### 1. Health Check
```http
GET /api/parser-ai/ai/health
```

**Ответ:**
```json
{
  "service": "ai-parser-service",
  "status": "healthy",
  "timestamp": "2025-10-08T18:34:46.993Z",
  "dependencies": {
    "mistral": {
      "status": "healthy",
      "model": "mistral-7b"
    },
    "playwright": {
      "status": "healthy"
    }
  }
}
```

#### 2. Запуск AI-парсинга
```http
POST /api/parser-ai/tasks/:taskId/ai-parse
```

**Тело запроса:**
```json
{
  "url": "https://example.com",
  "sourceType": "documentation",
  "enableHMM": true,
  "maxPages": 5
}
```

**Ответ:**
```json
{
  "taskId": "task-abc123",
  "status": "completed",
  "extractedData": [...],
  "hmmState": "completed",
  "actionsPerformed": 15
}
```

#### 3. Генерация человекоподобного движения мыши
```http
POST /api/parser-ai/mouse/generate
```

**Тело запроса:**
```json
{
  "taskId": "task-abc123",
  "actionType": "click",
  "targetElement": "button",
  "fromX": 100,
  "fromY": 100,
  "toX": 500,
  "toY": 300
}
```

**Ответ:**
```json
{
  "id": "uuid-123",
  "taskId": "task-abc123",
  "bezierPoints": [
    {"x": 100, "y": 100, "timestamp": 0},
    {"x": 250, "y": 180, "timestamp": 150},
    {"x": 500, "y": 300, "timestamp": 300}
  ],
  "aiGenerated": true,
  "aiParameters": {
    "jitter": 0.15,
    "speed": 1.2,
    "curvature": 0.8,
    "pauseProbability": 0.3,
    "overshoot": 0.05
  }
}
```

#### 4. Получить состояние HMM
```http
GET /api/parser-ai/tasks/:taskId/hmm
```

**Ответ:**
```json
{
  "id": "uuid-456",
  "taskId": "task-abc123",
  "currentState": "extracting",
  "transitionProbabilities": {
    "exploring": 0.2,
    "extracting": 0.5,
    "refining": 0.3
  },
  "observations": [
    {"state": "exploring", "success": true, "timestamp": "..."},
    {"state": "extracting", "success": true, "timestamp": "..."}
  ]
}
```

#### 5. Получить действия в браузере
```http
GET /api/parser-ai/tasks/:taskId/actions?limit=10
```

**Ответ:**
```json
[
  {
    "id": "uuid-789",
    "taskId": "task-abc123",
    "actionType": "navigate",
    "targetUrl": "https://example.com",
    "status": "completed",
    "result": {"pageLoaded": true}
  },
  {
    "id": "uuid-790",
    "actionType": "click",
    "selector": "button.submit",
    "status": "completed"
  }
]
```

#### 6. Получить движения мыши
```http
GET /api/parser-ai/tasks/:taskId/movements?limit=10
```

#### 7. Получить лог AI-решений
```http
GET /api/parser-ai/tasks/:taskId/ai-decisions?limit=10
```

**Ответ:**
```json
[
  {
    "id": "uuid-001",
    "taskId": "task-abc123",
    "decisionType": "selector_generation",
    "input": {"html": "...", "targetDescription": "submit button"},
    "output": {"selector": "button.submit", "confidence": 0.95},
    "mistralResponse": "Based on HTML analysis...",
    "success": true
  }
]
```

---

## Интеграция

### 1. Интеграция с Node.js/Express приложениями

```typescript
// server/routes.ts
import { parserRouter } from "../parser-service/infrastructure/routes";

export async function registerRoutes(app: Express) {
  // Регистрация AI Parser routes
  app.use("/api/parser-ai", parserRouter);
  
  // Остальные routes...
}
```

### 2. Интеграция с AiGentForge

```typescript
// Пример создания агента для парсинга
const agent = await createAgentUseCase.execute({
  name: "Web Parser Agent",
  description: "AI agent for intelligent web parsing",
  task: "Parse business websites and extract contact information",
  templateId: "web-parser-template"
});

// Использование парсера через агента
const parsingResult = await fetch('/api/parser-ai/tasks/my-task/ai-parse', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    url: 'https://target-website.com',
    sourceType: 'business_info',
    enableHMM: true,
    maxPages: 10
  })
});
```

### 3. Интеграция с LeadGen Pro

```typescript
// leadgen/services/WebParserIntegration.ts
export class WebParserIntegration {
  async parseBusinessWebsite(url: string): Promise<BusinessProfile> {
    // 1. Запуск AI-парсинга
    const taskId = `leadgen-${Date.now()}`;
    const result = await fetch(`/api/parser-ai/tasks/${taskId}/ai-parse`, {
      method: 'POST',
      body: JSON.stringify({
        url,
        sourceType: 'business_profile',
        enableHMM: true,
        maxPages: 5
      })
    });
    
    // 2. Обработка результатов
    const data = await result.json();
    return this.mapToBusinessProfile(data);
  }
}
```

### 4. Автономное использование (Standalone)

```typescript
// Настройка DI контейнера
import { DependencyContainer } from './parser-service/infrastructure/DependencyInjection';

// Получение use case
const executeParsingUseCase = DependencyContainer.getExecuteAIParsingUseCase();

// Выполнение парсинга
const result = await executeParsingUseCase.execute({
  taskId: 'standalone-task-123',
  url: 'https://example.com',
  sourceType: 'documentation',
  enableHMM: true,
  maxPages: 5
});

console.log('Parsing completed:', result);
```

---

## Управление через AI агента

### Концепция AI-управляемого парсера

AI Web Parser может быть полностью управляем другим AI агентом (например, созданным в AiGentForge). Это позволяет создавать сложные автоматизированные рабочие процессы.

### Сценарии использования

#### 1. Агент-оркестратор
AI агент может управлять несколькими парсерами одновременно:

```typescript
// AI Agent Use Case: Multi-site parsing orchestration
class OrchestratorAgent {
  async parseMultipleSites(urls: string[]) {
    const tasks = urls.map((url, index) => ({
      taskId: `orchestrator-${index}`,
      url,
      sourceType: 'auto-detect'
    }));
    
    // Параллельный запуск парсеров
    const results = await Promise.all(
      tasks.map(task => 
        fetch('/api/parser-ai/tasks/${task.taskId}/ai-parse', {
          method: 'POST',
          body: JSON.stringify(task)
        })
      )
    );
    
    return this.aggregateResults(results);
  }
}
```

#### 2. Адаптивный агент с обратной связью
AI агент анализирует результаты парсинга и корректирует стратегию:

```typescript
class AdaptiveParserAgent {
  async intelligentParse(url: string) {
    const taskId = `adaptive-${Date.now()}`;
    
    // 1. Первичный парсинг
    let result = await this.executeParsing(taskId, url);
    
    // 2. Анализ HMM состояния
    const hmmState = await fetch(`/api/parser-ai/tasks/${taskId}/hmm`);
    const state = await hmmState.json();
    
    // 3. Если парсинг неуспешен - корректировка
    if (state.currentState === 'failed') {
      const decisions = await fetch(`/api/parser-ai/tasks/${taskId}/ai-decisions`);
      const log = await decisions.json();
      
      // AI анализирует ошибки и пробует новую стратегию
      const newStrategy = await this.analyzeFailures(log);
      result = await this.executeParsing(`${taskId}-retry`, url, newStrategy);
    }
    
    return result;
  }
}
```

#### 3. Обучающийся агент
AI агент использует историю парсинга для улучшения:

```typescript
class LearningParserAgent {
  async parseWithLearning(url: string, vertical: string) {
    // 1. Получить историю успешных парсингов для этого vertical
    const history = await this.getSuccessfulParsings(vertical);
    
    // 2. Использовать паттерны из истории
    const strategy = this.buildStrategyFromHistory(history);
    
    // 3. Выполнить парсинг
    const result = await this.executeParsing(url, strategy);
    
    // 4. Сохранить результат для обучения
    if (result.success) {
      await this.saveToHistory(vertical, result);
    }
    
    return result;
  }
}
```

### API для AI-агентов

#### Получение аналитики для принятия решений
```http
GET /api/parser-ai/tasks/:taskId/ai-decisions?limit=100
```

AI агент может анализировать:
- Какие селекторы были успешными
- Какие действия привели к успеху
- Какие паттерны работают для конкретного типа сайтов

#### Управление HMM стратегией
```typescript
// AI агент может влиять на HMM через наблюдения
const observation = {
  state: 'exploring',
  success: true,
  confidence: 0.95
};

// HMM автоматически обновит вероятности переходов
```

---

## Установка и развертывание

### Системные требования

- **Node.js**: 18.x или выше
- **PostgreSQL**: 14.x или выше
- **Mistral-7B**: Доступ к Ollama API (опционально, есть fallback)
- **Playwright**: Chromium browser (автоматически устанавливается)

### Шаг 1: Установка зависимостей

```bash
# Перейти в директорию parser-service
cd parser-service

# Установить зависимости
npm install
```

### Шаг 2: Настройка базы данных

```bash
# Создать базу данных PostgreSQL
createdb ai_parser_db

# Настроить переменные окружения
cp .env.example .env
```

**.env файл:**
```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/ai_parser_db
PGHOST=localhost
PGPORT=5432
PGUSER=your_user
PGPASSWORD=your_password
PGDATABASE=ai_parser_db

# Mistral AI (опционально)
MISTRAL_API_URL=http://89.208.107.67:8000
# или локальный Ollama
# MISTRAL_API_URL=http://localhost:11434

# Session (для интеграции)
SESSION_SECRET=your-secret-key-here
```

### Шаг 3: Инициализация схемы БД

```bash
# Синхронизировать схему с БД
npm run db:push
```

Это создаст 4 таблицы:
- `hmm_states`
- `mouse_movements`
- `browser_actions`
- `ai_decisions_log`

### Шаг 4: Установка Playwright

```bash
# Установить Chromium browser
npx playwright install chromium
```

### Шаг 5: Запуск сервиса

#### Режим разработки
```bash
npm run dev
```

#### Режим продакшн
```bash
# Сборка TypeScript
npm run build

# Запуск
npm start
```

### Шаг 6: Проверка работоспособности

```bash
# Health check
curl http://localhost:5000/api/parser-ai/ai/health

# Должен вернуть:
{
  "service": "ai-parser-service",
  "status": "healthy",
  "timestamp": "...",
  "dependencies": {...}
}
```

### Интеграция в существующий проект

1. **Скопировать директорию `parser-service`** в ваш проект

2. **Добавить routes в main server:**

```typescript
// server/routes.ts или server/index.ts
import { parserRouter } from "../parser-service/infrastructure/routes";

app.use("/api/parser-ai", parserRouter);
```

3. **Добавить зависимости в package.json:**

```json
{
  "dependencies": {
    "@neondatabase/serverless": "^0.9.0",
    "playwright": "^1.40.0",
    "drizzle-orm": "^0.29.0",
    "axios": "^1.6.0"
  }
}
```

4. **Запустить миграции БД** (если используется общая БД):

```bash
npm run db:push
```

---

## Примеры использования

### Пример 1: Простой парсинг сайта

```typescript
// Запуск парсинга
const response = await fetch('http://localhost:5000/api/parser-ai/tasks/task-001/ai-parse', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    url: 'https://example.com/contacts',
    sourceType: 'contact_info',
    enableHMM: true,
    maxPages: 3
  })
});

const result = await response.json();
console.log('Extracted data:', result.extractedData);
```

### Пример 2: Генерация человекоподобного клика

```typescript
// Генерировать движение мыши для клика на кнопку
const movement = await fetch('http://localhost:5000/api/parser-ai/mouse/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    taskId: 'task-001',
    actionType: 'click',
    targetElement: 'button.submit',
    fromX: 100,
    fromY: 150,
    toX: 450,
    toY: 320
  })
});

const mouseData = await movement.json();

// Воспроизвести движение
for (const point of mouseData.bezierPoints) {
  await moveMouse(point.x, point.y);
  await sleep(point.timestamp);
}
```

### Пример 3: Мониторинг состояния HMM

```typescript
// Получить текущее состояние HMM
const hmmState = await fetch('http://localhost:5000/api/parser-ai/tasks/task-001/hmm');
const state = await hmmState.json();

console.log('Current state:', state.currentState);
console.log('Transition probabilities:', state.transitionProbabilities);

// Принять решение на основе состояния
if (state.currentState === 'failed') {
  console.log('Parsing failed, retrying with different strategy...');
  // Retry logic
} else if (state.currentState === 'completed') {
  console.log('Parsing completed successfully!');
  // Process results
}
```

### Пример 4: Анализ AI-решений

```typescript
// Получить лог AI-решений
const decisions = await fetch('http://localhost:5000/api/parser-ai/tasks/task-001/ai-decisions');
const log = await decisions.json();

// Найти успешные паттерны
const successfulSelectors = log
  .filter(d => d.decisionType === 'selector_generation' && d.success)
  .map(d => d.output.selector);

console.log('Successful selectors:', successfulSelectors);

// Использовать для следующего парсинга
const nextParsing = {
  preferredSelectors: successfulSelectors,
  // ...
};
```

### Пример 5: Парсинг с fallback

```typescript
async function parseWithFallback(url: string) {
  try {
    // Попытка с AI
    const result = await fetch('/api/parser-ai/tasks/task-001/ai-parse', {
      method: 'POST',
      body: JSON.stringify({
        url,
        sourceType: 'auto',
        enableHMM: true
      })
    });
    
    return await result.json();
  } catch (error) {
    console.log('AI parsing failed, using heuristic fallback...');
    
    // Fallback уже встроен в систему, но можно добавить свою логику
    const fallbackResult = await fetch('/api/parser-ai/tasks/task-001/ai-parse', {
      method: 'POST',
      body: JSON.stringify({
        url,
        sourceType: 'auto',
        enableHMM: false, // Отключить HMM для простого парсинга
        useHeuristics: true
      })
    });
    
    return await fallbackResult.json();
  }
}
```

---

## Troubleshooting

### Проблема: Mistral недоступен
**Решение:** Система автоматически переключится на fallback алгоритм. Проверьте переменную `MISTRAL_API_URL` в `.env`

### Проблема: Playwright ошибки
**Решение:** Переустановите браузеры:
```bash
npx playwright install chromium --force
```

### Проблема: Таблицы не созданы
**Решение:** Запустите синхронизацию схемы:
```bash
npm run db:push --force
```

### Проблема: Memory leaks при большом объеме
**Решение:** Увеличьте лимит Node.js:
```bash
NODE_OPTIONS="--max-old-space-size=4096" npm start
```

---

## Расширение функциональности

### Добавление нового Use Case

1. Создать интерфейс в `application/ports/`
2. Создать use case в `application/use-cases/`
3. Добавить реализацию в `adapters/`
4. Зарегистрировать в `DependencyInjection.ts`
5. Добавить route в `infrastructure/routes.ts`

### Добавление нового Gateway

1. Создать интерфейс в `adapters/gateways/I[Name]Gateway.ts`
2. Создать реализацию в `infrastructure/services/[Name]Service.ts`
3. Зарегистрировать в `DependencyInjection.ts`
4. Использовать в use cases через constructor injection

---

## Поддержка

**Документация проекта:** `replit.md`  
**API документация:** `parser-service/README.md`  
**Примеры интеграции:** `parser-service/INTEGRATION_GUIDE.md`

---

## Лицензия

Разработано для AiGentForge и LeadGen Pro проектов.  
Clean Architecture implementation by Replit Agent.

**Версия:** 1.0.0  
**Дата:** 2025-10-08
